


**********************************************************
*************  Important Instructions Follow  ************
**********************************************************

All files exported to: Z:\\11\\60\\1160921\\77\Altium\2016-07-11_00-52-10\2016-07-11_00-52-10


**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************


Symbol "WB_DIODE_SCHOTTKY" renamed to "WB_DIODE_SCHOTTK"
Component "06031A100FAT2A" renamed to "06031A100FAT2A"
Component "C1608X7R1H104K" renamed to "C1608X7R1H104K"
Component "CL21C102JBCNFNC" renamed to "CL21C102JBCNFNC"
Component "CC0805KRX7R9BB271" renamed to "CC0805KRX7R9BB27"
Component "C3225X7S2A475M200AB" renamed to "C3225X7S2A475M20"
Component "HMK212B7104KG-T" renamed to "HMK212B7104KG-T"
Component "UUD1V270MCL1GS" renamed to "UUD1V270MCL1GS"
Component "CC0805KRX7R9BB152" renamed to "CC0805KRX7R9BB15"
Component "0805YC224KAT2A" renamed to "0805YC224KAT2A"
Component "GRM216R71H103KA01D" renamed to "GRM216R71H103KA0"
Component "EMK212B7105KG-T" renamed to "EMK212B7105KG-T"
Component "C2012X7R1E105K" renamed to "C2012X7R1E105K"
Component "SS2PH10-M3" renamed to "SS2PH10-M3"
Component "10MQ100NTRPBF" renamed to "10MQ100NTRPBF"
Component "MBRS2040LT3G" renamed to "MBRS2040LT3G"
Component "ERJ-6ENF8662V" renamed to "ERJ-6ENF8662V"
Component "MSS1210-104KEB" renamed to "MSS1210-104KEB"
Component "CSD19534Q5A" renamed to "CSD19534Q5A"
Component "BSC320N20NS3_G" renamed to "BSC320N20NS3_G"
Component "NET_TIED" renamed to "NET_TIED"
Component "ERJ-6ENF4422V" renamed to "ERJ-6ENF4422V"
Component "CRCW060310K0FKEA" renamed to "CRCW060310K0FKEA"
Component "ERJ-6ENF1004V" renamed to "ERJ-6ENF1004V"
Component "ERJ-6ENF1431V" renamed to "ERJ-6ENF1431V"
Component "ERJ-6ENF2802V" renamed to "ERJ-6ENF2802V"
Component "ERJ-6ENF1213V" renamed to "ERJ-6ENF1213V"
Component "CSR1206FK25L0" renamed to "CSR1206FK25L0"
Component "CRCW12061K00FKEA" renamed to "CRCW12061K00FKEA"
Component "ERJ-6ENF1432V" renamed to "ERJ-6ENF1432V"
Component "ERJ-6ENF3401V" renamed to "ERJ-6ENF3401V"
Component "LM5116MHX/NOPB" renamed to "LM5116MHX/NOPB"
Component "TP-1502" renamed to "TP-1502"
Warning: Symbol "WB_CAPACITOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "VdsMax" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "IdsMax" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "Rdson45" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "QgTyp" references missing text style ""
Warning: Symbol "BSC320N20NS3_G" attribute "Quantity" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "Datasheet URL" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "Frequency" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "Imax" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "Package" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "Mktg_Package" references missing text style ""
Warning: Symbol "LM5116MHX" attribute "NSID" references missing text style ""
