


**********************************************************
*************  Important Instructions Follow  ************
**********************************************************

All files exported to: Z:\\11\\60\\1160921\\77\DesignSpark\2016-07-11_00-56-04\2016-07-11_00-56-04.DSL


**********************************************************
***************** SCHEMATIC Instructions  *******************
**********************************************************

To import your new Schematic into Design Spark:

1. Unzip the downloaded folder files to a local directory.
2. Start the Design Spark Schematic program.
3. From the menu select "File"->"Open".
4. Select the file named in the path above ending with ".dssch"
(if ".dssch" is unvailable, Select view All Files (*.*) above the "Open" button)
	and "Open" the file.
5. A pop up message will show, Select "YES"; Your schematic should be viewable within DesignSpart now.

For instructions on import to DesignSpark please see:
http://www.designspark.com/knowledge-item/designspark-Schematic-webench-import



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD into Design Spark:

1. 	Unzip the downloaded folder files to a local directory.
2	Start the Design Spark PCB program.
3. 	From the menu select "File"->"Open".
4.	Select the file named in the path above ending with ".eip"
	and "Open" the file.
5. 	All planes will need to be repoured after Import.
	a. Each Copper Pour Region should be surrounded by a line.
	b. Select a line from the polygon you wish to repour, when
	   mousing over line tooltip should indicate that the line is
	   a part of a Copper Pour Area.
	c. Right click on the line and a menu should appear, select
	   "Pour Copper". This item should have an icon next to it.
	d. The plane will then be poured.
	e. Make sure that copper pours on ALL layers are completed.
6. Your board should be viewable within DesignSpark now.

For instructions on import to DesignSpark please see:
http://www.designspark.com/knowledge-item/designspark-pcb-webench-import



To view a video tutorial, please visit:
http://youtu.be/KLwMsEBa3Mo

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY into DesignSpark:

1.  Open DesignSpark
2.  On the menu, go to "File" then "Libraries" to open "Library Manager"
3.  In "Library Manager", select the "Schematic Symbols" tab.
4.  At the end of the "Library:" path is a button for "New Lib...",
press that.
5.  Browse to a location to save the library to, and give it a name. When
done, "Library Manager" should already have it selected at the top.
6.  In the middle column of buttons, select "Add File...".  Browse to the
library exported by UL and select it (".DSL" extension).
7.  Next will be a window for "Eagle Symbol Library", with places for
"Schematic Design" name, "Technology File", and so on.  Just hit OK.
8.  When complete, the Library Manager should list the names of all
symbols imported.
9.  Next in "Library Manager", select the "PCB Symbols" tab.
10. At the end of the "Library:" path is a button for "New Lib...",
press that.
11. Browse to a location to save the library to, and give it a name.
When done, "Library Manager" should already have it selected at
the top.
12. In the middle column of buttons, select "Add File...".  Browse to the
library exported by UL and select it (".DSL" extension).
13. Next will be a window for "Eagle Footprint Library", with places for
"Schematic Design" name, "Technology File", and so on.  Just hit OK.
14. When complete, the Library Manager should list the names of all
footprints imported.
15. Next in "Library Manager", select the "Components" tab.
16. At the end of the "Library:" path is a button for "New Lib...",
press that.
17. Browse to a location to save the library to, and give it a name. When
done, "Library Manager" should already have it selected at the top.
18. In the middle column of buttons, select "Add File...".  Browse to
the library exported by UL and select it (".DSL" extension).
19. When complete, the Library Manager should list the names of all
components imported.
20. "Library Manager" can be closed.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/DesignSpark_import.html

You may also find this video beneficial:
http://youtu.be/6bHvPsHG4DQ

**********************************************************
**********************************************************
**********************************************************





**********************************************************
*************  Important Instructions Follow  ************
**********************************************************

All files exported to: Z:\\11\\60\\1160921\\77\DesignSpark\2016-07-11_00-56-04\2016-07-11_00-56-04.DSL


**********************************************************
***************** SCHEMATIC Instructions  *******************
**********************************************************

To import your new Schematic into Design Spark:

1. Unzip the downloaded folder files to a local directory.
2. Start the Design Spark Schematic program.
3. From the menu select "File"->"Open".
4. Select the file named in the path above ending with ".dssch"
(if ".dssch" is unvailable, Select view All Files (*.*) above the "Open" button)
	and "Open" the file.
5. A pop up message will show, Select "YES"; Your schematic should be viewable within DesignSpart now.

For instructions on import to DesignSpark please see:
http://www.designspark.com/knowledge-item/designspark-Schematic-webench-import



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD into Design Spark:

1. 	Unzip the downloaded folder files to a local directory.
2	Start the Design Spark PCB program.
3. 	From the menu select "File"->"Open".
4.	Select the file named in the path above ending with ".eip"
	and "Open" the file.
5. 	All planes will need to be repoured after Import.
	a. Each Copper Pour Region should be surrounded by a line.
	b. Select a line from the polygon you wish to repour, when
	   mousing over line tooltip should indicate that the line is
	   a part of a Copper Pour Area.
	c. Right click on the line and a menu should appear, select
	   "Pour Copper". This item should have an icon next to it.
	d. The plane will then be poured.
	e. Make sure that copper pours on ALL layers are completed.
6. Your board should be viewable within DesignSpark now.

For instructions on import to DesignSpark please see:
http://www.designspark.com/knowledge-item/designspark-pcb-webench-import



To view a video tutorial, please visit:
http://youtu.be/KLwMsEBa3Mo

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY into DesignSpark:

1.  Open DesignSpark
2.  On the menu, go to "File" then "Libraries" to open "Library Manager"
3.  In "Library Manager", select the "Schematic Symbols" tab.
4.  At the end of the "Library:" path is a button for "New Lib...",
press that.
5.  Browse to a location to save the library to, and give it a name. When
done, "Library Manager" should already have it selected at the top.
6.  In the middle column of buttons, select "Add File...".  Browse to the
library exported by UL and select it (".DSL" extension).
7.  Next will be a window for "Eagle Symbol Library", with places for
"Schematic Design" name, "Technology File", and so on.  Just hit OK.
8.  When complete, the Library Manager should list the names of all
symbols imported.
9.  Next in "Library Manager", select the "PCB Symbols" tab.
10. At the end of the "Library:" path is a button for "New Lib...",
press that.
11. Browse to a location to save the library to, and give it a name.
When done, "Library Manager" should already have it selected at
the top.
12. In the middle column of buttons, select "Add File...".  Browse to the
library exported by UL and select it (".DSL" extension).
13. Next will be a window for "Eagle Footprint Library", with places for
"Schematic Design" name, "Technology File", and so on.  Just hit OK.
14. When complete, the Library Manager should list the names of all
footprints imported.
15. Next in "Library Manager", select the "Components" tab.
16. At the end of the "Library:" path is a button for "New Lib...",
press that.
17. Browse to a location to save the library to, and give it a name. When
done, "Library Manager" should already have it selected at the top.
18. In the middle column of buttons, select "Add File...".  Browse to
the library exported by UL and select it (".DSL" extension).
19. When complete, the Library Manager should list the names of all
components imported.
20. "Library Manager" can be closed.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/DesignSpark_import.html

You may also find this video beneficial:
http://youtu.be/6bHvPsHG4DQ

**********************************************************
**********************************************************
**********************************************************


Component "GRM216R71H103KA01D" renamed to "GRM216R71H103KA01D"
Component "CL21C102JBCNFNC" renamed to "CL21C102JBCNFNC"
Component "CC0805KRX7R9BB271" renamed to "CC0805KRX7R9BB271"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "HMK212B7104KG-T" renamed to "HMK212B7104KG-T"
Component "UUD1V270MCL1GS" renamed to "UUD1V270MCL1GS"
Component "CC0805KRX7R9BB152" renamed to "CC0805KRX7R9BB152"
Component "EMK212B7105KG-T" renamed to "EMK212B7105KG-T"
Component "SS2PH10-M3" renamed to "SS2PH10-M3"
Component "WB_GND" renamed to "WB_GND"
Component "MSS1210-104KEB" renamed to "MSS1210-104KEB"
Component "CSD19534Q5A" renamed to "CSD19534Q5A"
Component "BSC320N20NS3 G" renamed to "BSC320N20NS3 G"
Component "ERJ-6ENF4422V" renamed to "ERJ-6ENF4422V"
Component "ERJ-6ENF1004V" renamed to "ERJ-6ENF1004V"
Component "ERJ-6ENF1431V" renamed to "ERJ-6ENF1431V"
Component "ERJ-6ENF2802V" renamed to "ERJ-6ENF2802V"
Component "ERJ-6ENF1213V" renamed to "ERJ-6ENF1213V"
Component "CSR1206FK25L0" renamed to "CSR1206FK25L0"
Component "ERJ-6ENF1432V" renamed to "ERJ-6ENF1432V"
Component "ERJ-6ENF3401V" renamed to "ERJ-6ENF3401V"
Component "ERJ-6ENF8662V" renamed to "ERJ-6ENF8662V"
Component "LM5116MHX/NOPB" renamed to "LM5116MHX/NOPB"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "C3225X7S2A475M200AB" renamed to "C3225X7S2A475M200AB"


Ultra Librarian Gold 8.1.44 Process Report


Message - Symbol "WB_CONTINUATION" had to be given a REFDES attribute.
Message - Symbol "WB_N_MOSFET" had to be given a REFDES attribute.
Message - Symbol "WB_BLOCK_IO" had to be given a REFDES attribute.
Message - Symbol "WB_LM5116" had to be given a REFDES attribute.
Message - Symbol "WB_PRIM_AC_VOLTAGE_SOURCE" had to be given a REFDES attribute.
Message - Symbol "WB_SYNC_CAPACITOR" had to be given a REFDES attribute.
Message - Symbol "WB_PRIMITIVE_INDUCTOR" had to be given a REFDES attribute.
Message - Symbol "WB_VOLTAGE_PROBE" had to be given a REFDES attribute.
Message - Symbol "WB_PWL_VOLTAGE_SOURCE" had to be given a REFDES attribute.
Message - Symbol "WB_SOURCE_RESISTOR" had to be given a REFDES attribute.
Message - Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" had to be given a REFDES attribute.
Message - Symbol "WB_CURRENT_PROBE" had to be given a REFDES attribute.
Message - Symbol "WB_LOAD_RESISTOR" had to be given a REFDES attribute.
Message - Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" had to be given a REFDES attribute.
Message - Symbol "WB_STARTUP_VOLTAGE_SOURCE" had to be given a REFDES attribute.
Message - Symbol "WB_PWL_CURRENT_LOAD" had to be given a REFDES attribute.
Message - Symbol "WB_PRIMITIVE_BATTERY" had to be given a REFDES attribute.
Message - Component "GRM216R71H103KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM216R71H103KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM216R71H103KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM216R71H103KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C102JBCNFNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C102JBCNFNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C102JBCNFNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C102JBCNFNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C102JBCNFNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB271" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB271" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB271" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB271" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "HMK212B7104KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "HMK212B7104KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "HMK212B7104KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "HMK212B7104KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UUD1V270MCL1GS" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UUD1V270MCL1GS" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UUD1V270MCL1GS" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UUD1V270MCL1GS" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB152" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB152" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB152" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CC0805KRX7R9BB152" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7105KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7105KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7105KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7105KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS2PH10-M3" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS2PH10-M3" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS2PH10-M3" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SS2PH10-M3" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1210-104KEB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1210-104KEB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1210-104KEB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1210-104KEB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "BSC320N20NS3 G" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF4422V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF4422V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF4422V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1004V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1004V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1004V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1431V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1431V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1431V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2802V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2802V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2802V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1213V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1213V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1213V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSR1206FK25L0" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSR1206FK25L0" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSR1206FK25L0" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1432V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1432V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1432V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3401V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3401V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3401V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8662V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8662V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8662V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5116MHX/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7S2A475M200AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7S2A475M200AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7S2A475M200AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7S2A475M200AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7S2A475M200AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  23
Padstack count:   13
Pattern count:    9
Symbol count:     28
Component count:  25

Export

The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM5116 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM5116 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_AC_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_AC_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SYNC_CAPACITOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SYNC_CAPACITOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_INDUCTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_INDUCTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
