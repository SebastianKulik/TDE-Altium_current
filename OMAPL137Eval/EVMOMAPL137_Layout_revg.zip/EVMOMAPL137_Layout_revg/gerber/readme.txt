Date : 09/10/09 

ion Design Inc.
4410 Shoalwood
Austin, Texas  78756          
                        
Design Manager    : Darren Larson
                  : (512)260-5778
             Email: dlarson@iondsn.com
        Cell Phone: (512)630-9814

Designer Contact  : Hector M. Arredondo
                  : (512)260-5778
            Email : hectora@iondsn.com

Job#  090909SPD1

README for spd150_gerbers.zip

Files contained in the zip file:

README.1st      This file
spdlyr1.150   	Layer 1
spdlyr2.150     Layer 2
spdlyr3.150   	Layer 3
spdlyr4.150     Layer 4
spdlyr5.150   	Layer 5
spdlyr6.150     Layer 6
spdlyr7.150   	Layer 7
spdlyr8.150     Layer 8
spdlyr9.150   	Layer 9
spdlyr10.150    Layer 10
spdsmc.150   	Soldermask Layer 1 Side (Component)
spdsms.150    	Soldermask Layer 10 Side (Solder)
spdspc.150    	Solder Paste Layer 1 Side (for Assembly ONLY)(Ref.ONLY)
spdsps.150    	Solder Paste Layer 10 Side (for Assembly ONLY)(Ref.ONLY)
spdtslk.150 	Silk Screen Layer 1 side
spdbslk.150 	Silk Screen Layer 10 side
spdfab.150    	Fabrication Drawing Page 1(for Ref. ONLY)
spdassy1.150    Assembly Drawing Page 1 (for Ref. ONLY)
ncdrill-1-10.tap 	Drill tape
nc_param.txt 		Drill tape setup file
ncdrill.log    		Drill tape composite file (for Reference ONLY)
spd150.ipc     		IPC-D-356 netlist (for Checking ONLY)
art_param.txt  		Artwork Format File (for Ref. ONLY)
spdcen.150		Placement file for Assembly (for Ref. Only)
spdnet.150 		Allegro Netlist (for Ref. Only)


Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.
