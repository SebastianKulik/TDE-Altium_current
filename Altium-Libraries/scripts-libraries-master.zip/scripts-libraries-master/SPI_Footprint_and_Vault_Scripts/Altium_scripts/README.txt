Hi to anyone looking at all this new code and saying:  

"Wow!  What is all this??
If only there were documentation and distribution zip files and so forth!"

I plan to write documentation to describe how to use these files.
Consider it to be "coming soon".

--Jeff Collins 2012-12-13