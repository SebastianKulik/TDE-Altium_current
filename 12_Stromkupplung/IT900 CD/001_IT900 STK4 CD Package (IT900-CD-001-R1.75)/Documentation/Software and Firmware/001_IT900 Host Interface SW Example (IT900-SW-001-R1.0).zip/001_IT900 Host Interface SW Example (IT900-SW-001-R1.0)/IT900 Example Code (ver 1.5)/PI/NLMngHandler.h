/*----------------------------------------------------------------------
*	Author		: Tsirlin Alexey
*	Copyright	: (c)2005 Yitran Communications Ltd.
*	Description	: NLMNGHANDLER Header File
*-----------------------------------------------------------------------
* Revision list
*-----------------------------------------------------------------------
*	Version	Author	Date		Changes
*	  0.1	Alexey	03/11/06	Started design
*-----------------------------------------------------------------------*/
#ifndef NLMNGHANDLER_H
#define NLMNGHANDLER_H

#ifdef  NLMNGHANDLER_H_MAIN_FILE
#define	NLMNGHANDLER_H_EXT
#else
#define	NLMNGHANDLER_H_EXT	extern
#endif

#include <HAL_UART.h>
#include <HAL_Timer.h>
#include <HAL_IO.h>
#include <PLCModemDriver.h>
#include <string.h>


/////////////////////////////////////
// Struct and Typedef DeclNLMNGtions //
/////////////////////////////////////
#define NLMNGHANDLER_IN_BUFFER_LENGTH 128


typedef struct _NLMNGHANDLER_STR
{
	// NLMNG incoming packet buffer
	BYTE sbyNLMngIncomingBuffer[NLMNGHANDLER_IN_BUFFER_LENGTH];
	// NLMNG incoming packet length
	WORD wNLMngIncomingBufferLength;
	// Connected to BS flag
	BOOL bConnectedToNC;
	// Admission request flag
	BOOL bAdmissionRequest;
	// Network Assigned flag
	BOOL bNetworkAddressAssigned;
}NLMNGHANDLER_STR;

//NLMNG Interface Packets
#define NLMNG_HEADER_LO			    0x00
#define NLMNG_HEADER_HI			    0x01
#define NLMNG_EI_SUBTYPE			    0x02
#define NLMNG_EI_HEAD_SUBTYPE_LENGTH	0x03
#define NLMNG_EI_PAYLOAD_IDX			0x03


#define NLMNG_EI_CHECKSUM_LENGTH		0x01

#define NLMNG_PACKET_TYPE			0x05
#define NLMNG_PROTOCOL_VERSION	0x05

// Get Database indexes
#define NLMNG_EI_GET_DB_PNLMNGM_INDEX_IDX			NLMNG_EI_PAYLOAD_IDX
#define NLMNG_EI_GET_DB_PNLMNGM_INDEX_SZ			1
#define NLMNG_EI_GET_DB_PNLMNGM_PAYLOAD_SZ			(NLMNG_EI_GET_DB_PNLMNGM_INDEX_IDX + NLMNG_EI_GET_DB_PNLMNGM_INDEX_SZ)

//Get database response
#define NLMNG_EI_GET_DB_RESP_PNLMNGM_INDEX_IDX		NLMNG_EI_PAYLOAD_IDX
#define NLMNG_EI_GET_DB_RESP_PNLMNGM_INDEX_SZ		1
#define NLMNG_EI_GET_DB_RESP_PNLMNGM_VALUE_IDX		(NLMNG_EI_GET_DB_RESP_PNLMNGM_INDEX_IDX + NLMNG_EI_GET_DB_RESP_PNLMNGM_INDEX_SZ)
#define NLMNG_EI_GET_DB_RESP_PNLMNGM_VALUE_SZ		4
#define NLMNG_EI_GET_DB_RESP_PAYLOAD_SZ				(NLMNG_EI_GET_DB_RESP_PNLMNGM_VALUE_IDX + NLMNG_EI_GET_DB_RESP_PNLMNGM_VALUE_SZ)

// Set NLMNG DB frame indeces and size
#define NLMNG_EI_DB_SET_PNLMNGM_INDEX_IDX			NLMNG_EI_PAYLOAD_IDX
#define NLMNG_EI_DB_SET_PNLMNGM_INDEX_SZ			1//	sizeof(struct NLMNG_RT_CONFIG_MONITOR_EXT_INT_CONFIG_PNLMNGMS)
#define NLMNG_EI_DB_SET_PNLMNGM_VALUE_IDX			(NLMNG_EI_DB_SET_PNLMNGM_INDEX_IDX + NLMNG_EI_DB_SET_PNLMNGM_INDEX_SZ)
#define NLMNG_EI_DB_SET_PNLMNGM_VALUE_SZ			4
#define NLMNG_EI_DB_SET_PNLMNGM_EEPROM_SAVE_IDX		(NLMNG_EI_DB_SET_PNLMNGM_VALUE_IDX + NLMNG_EI_DB_SET_PNLMNGM_VALUE_SZ)
#define NLMNG_EI_DB_SET_PNLMNGM_EEPROM_SAVE_SZ		1
#define NLMNG_EI_DB_SET_PAYLOAD_SZ					(NLMNG_EI_DB_SET_PNLMNGM_EEPROM_SAVE_IDX + NLMNG_EI_DB_SET_PNLMNGM_EEPROM_SAVE_SZ)

//Set Configuration response
#define NLMNG_EI_SET_CONFIG_RESP_STATUS_IDX			NLMNG_EI_PAYLOAD_IDX
#define NLMNG_EI_SET_CONFIG_RESP_STATUS_SZ			1
#define NLMNG_EI_SET_CONFIG_RESP_PAYLOAD_SZ			(NLMNG_EI_SET_CONFIG_RESP_STATUS_IDX + NLMNG_EI_SET_CONFIG_RESP_STATUS_SZ)

#define NLMNG_NODE_KEY_LENGTH						8

#define NLMNG_EI_SET_NODE_KEY_IDX					NLMNG_EI_PAYLOAD_IDX
#define NLMNG_EI_SET_NODE_KEY_PKT_LENGTH			NLMNG_NODE_KEY_LENGTH +\
													NLMNG_EI_PAYLOAD_IDX +\
   													NLMNG_EI_CHECKSUM_LENGTH

#define NLMNG_EI_GET_NODE_KEY_LENGTH				NLMNG_EI_PAYLOAD_IDX +\
   													NLMNG_EI_CHECKSUM_LENGTH
// Database index
#define NLMNG_EI_DB_NETWORK_SIZE_IDX				56
#define NLMNG_EI_DB_NC_DATABASE_SIZE_IDX			91
#define NLMNG_EI_DB_SN_SIZE_IDX						58
#define NLMNG_EI_DB_SN_IDX							0xBAAB

#define NLMNG_EI_DB_OPERATION_MODE_IDX				49

#define NLMNG_EI_DB_OPERATION_MODE_RS				0
#define NLMNG_EI_DB_OPERATION_MODE_BS				3

#define NLMNG_EI_DB_ADMISSION_MODE_IDX				60
#define	NLMNG_EI_DB_ADMISSION_MODE_AUTO				0x00
#define	NLMNG_EI_DB_ADMISSION_MODE_RANGE			0x01
#define	NLMNG_EI_DB_ADMISSION_MODE_RANGAPP			0x02
#define	NLMNG_EI_DB_ADMISSION_MODE_APP				0x03

#define NLMNG_EI_DB_ADMISSION_RES_APPROVED			0x0000
#define NLMNG_EI_DB_ADMISSION_RES_REFUSED			0x2000

#define NLMNG_EI_ADMISSION_RESPONSE_BUFF_LENGTH		0x25
#define NLMNG_SN_LIST_SIZE							2
#define NLMNG_SN_SIZE								16

// NL PNLMNGmeters Indexes:
#define NLParDef_eIdx_NLMngEnabled					0x0200

///////////////////////////
// Function DeclNLMNGtions //
///////////////////////////
NLMNGHANDLER_H_EXT BOOL NLMngHandler_bEnableNLMng(BOOL bEnable);
NLMNGHANDLER_H_EXT void NLMngHandler_Init(void);
void NLMngHandler_ClearIncomingPacketBuffer(void);
NLMNGHANDLER_H_EXT void NLMngHandler_MessageHandler(PBYTE pbyData, WORD wLength, BYTE byOpcode);
NLMNGHANDLER_H_EXT BOOL NLMngHandler_bSendCmdToNLMng
(
  PBYTE pbyData,
  WORD wLength,
  BOOL bWait
);

NLMNGHANDLER_H_EXT BOOL NLMngHandler_bIsConnectedToBase(void);


NLMNGHANDLER_H_EXT void NLMngHandler_ManageNLMng(void);
NLMNGHANDLER_H_EXT BOOL NLMngHandler_bIsNetIDAssigned(void);


// Service Functions:
NLMNGHANDLER_H_EXT DWORD dwStringToDWORD(PBYTE pbyData);
NLMNGHANDLER_H_EXT void DWORDToString(PBYTE pbyData, DWORD dwNum);


///////////////////////////////////
// Global module vars definition //
///////////////////////////////////

#ifdef NLMNGHANDLER_H_MAIN_FILE
NLMNGHANDLER_STR g_NLMngHandler_struct;
#endif // end NLMNGHANDLER_H_MAIN_FILE

#endif // end NLMNGHANDLER_H
