#define HAL_UART_H_MAIN_FILE
#include <HAL_UART.h>


UART_GLOBAL_T g_strUart;


/*----------------------------------------------------------------------
* Function name:		HAL_UART_Init
* Input:				void
* Output:				void
* Purpose:				this function inits the HAL_UART module,
						it prepares Rx and Tx buffers for both UART 
						modules
*-----------------------------------------------------------------------*/
void HAL_UART_Init(void)
{
	/* Initialize receive and transmit buffer counters */
	g_strUart.UART0_RxTail = 0;
	g_strUart.UART0_RxHead = 0;
	g_strUart.UART0_TxTail = 0;
	g_strUart.UART0_TxHead = 0;
	g_strUart.UART1_RxTail = 0;
	g_strUart.UART1_RxHead = 0;
	g_strUart.UART1_TxTail = 0;
	g_strUart.UART1_TxHead = 0;
	g_strUart.EROR = 0;
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0Init
* Input:				baud rate
* Output:				void
* Purpose:				This function inits UART0, it sets baud rate,
						enables transmitter and receiver
*-----------------------------------------------------------------------*/
void HAL_UART_UART0Init( unsigned int baudRate )
{
	BYTE x;
	g_strUart.UART0_CB_OnRxByte = HAL_UART_UART0_CB_OnRxLocalByte;
	#ifdef UART0_DoubleSpeed 
	UCSR0A = (1<<U2X0)
	#endif
	
	// Set the baud rate:
	UBRR0H = (BYTE) (baudRate>>8);                  
	UBRR0L = (BYTE) baudRate;
	
	// Enable UART0 receiver and transmitter,Enable UART0 receive interrupt(RXCIE0):
	UCSR0B = (   ( 1 << RXEN0 ) | ( 1 << TXEN0 ) |( 1 << RXCIE0 ) ); 
	
	// NumOf_StopBit and NumOf_DataBits are defined parameters in HAL_UART.h
	
	UCSR0C = ((NumOf_StopBit<<USBS0)|(NumOf_DataBits<<UCSZ00));
	
	// Initialize receive and transmit buffer counters 
	x = 0; 			    

	g_strUart.UART0_RxTail = x;
	g_strUart.UART0_RxHead = x;
	g_strUart.UART0_TxTail = x;
	g_strUart.UART0_TxHead = x;
	
} //end UART0Init




/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_DataInRxBuf
* Input:				void
* Output:				TRUE/FALSE
* Purpose:				This function checks if there incoming data 
						pending
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART0_DataInRxBuf( void )
{
	return( g_strUart.UART0_RxHead != g_strUart.UART0_RxTail );                                             
}//end UART0_DataInRxBuf



/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_DataInTxBuf
* Input:				void
* Output:				TRUE/FALSE
* Purpose:				This function checks if there outgoing data 
						pending
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART0_DataInTxBuf( void )
{
   return ( g_strUart.UART0_TxHead != g_strUart.UART0_TxTail );                                              
}//end UART0_DataInRxBuf



/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_Receive
* Input:				void
* Output:				incoming byte
* Purpose:				This function returns one incoming byte
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART0_Receive( void )
{
	BYTE bTmpTail;
		
	bTmpTail = ( g_strUart.UART0_RxTail + 1 ) & UART0_RX_BUFFER_MASK;// increase buffer index 
	
	g_strUart.UART0_RxTail = bTmpTail;  // Store new index 
	
	return g_strUart.UART0_RxBuf[bTmpTail];   //Return data 
}// end UART0_Receive




/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_RxInterrupt
* Input:				void
* Output:				void
* Purpose:				UART0 Rx interrupt, reads byte from Rx register
						and Calls Rx CB function
*-----------------------------------------------------------------------*/
ISR(USART0_RX_vect)
{

	BYTE byData;

	byData = UDR0; // Read the received data                  
	
	// Call Rx CB function if available
	if(g_strUart.UART0_CB_OnRxByte != NULL)
	{
	  g_strUart.UART0_CB_OnRxByte(byData,eHAL_UART_EVENT_UART0_Rx_Event);
	}

}// end UART0_RxInterrupt handler.

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_CB_OnRxLocalByte
* Input:				incoming byte
* Output:				void
* Purpose:				Local CB Rx function - stores the incoming
						byte in local buffer. local buffer can be read
						by HAL_UART_UART0_Receive function
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_CB_OnRxLocalByte(BYTE byData)
{
    BYTE bTmpHead;
	
	bTmpHead = ( g_strUart.UART0_RxHead + 1 ) & UART0_RX_BUFFER_MASK; //increase buffer index 

	g_strUart.UART0_RxHead = bTmpHead;      // Store new index 

	if ( bTmpHead == g_strUart.UART0_RxTail )
	 {
	  g_strUart.EROR=UART0_RxBuffer_OverFlow; // ERROR! Receive buffer overflow 
	 }
	else // in case buffer is not full
	 g_strUart.UART0_RxBuf[bTmpHead] = byData; // Store received data in buffer
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_SetOnRxByteCB
* Input:				pointer to external CB Rx function
* Output:				void
* Purpose:				Sets pointer to external Rx Callback function
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_SetOnRxByteCB(UART_pfCBOnRxByte pfn)
{
  g_strUart.UART0_CB_OnRxByte = pfn;
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_Transmit
* Input:				pointer to data, length
* Output:				void
* Purpose:				this function transmits data via UART. 
						this function copyes first byte into Tx register,
						enables Tx empty interrupt and waites until the
						whole data will be transmitted
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_Transmit(PBYTE data,WORD length) 
{	
	BYTE bTmpHead;
	WORD  wTmpLength=0;//the current index of the packet that is being sent

	// don't allow UART transmition if now on PLC Studio mode
	if(g_strUart.UART0_CB_OnRxByte(data,eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event))
	{
		return;
	}
	
	bTmpHead = g_strUart.UART0_TxHead;
	
	while(wTmpLength<length)
	 {
 	  //internal while loop:			
	  while ((((++bTmpHead)& UART0_TX_BUFFER_MASK) != g_strUart.UART0_TxTail )&&(wTmpLength<length)) 
	   { 
	    g_strUart.UART0_TxBuf[bTmpHead& UART0_TX_BUFFER_MASK] = data[wTmpLength++]; // Store data in buffer and increase
	   }
	 
	  bTmpHead--; // because the  variable is increased and unused on its last loop.	     
	  
	  g_strUart.UART0_TxHead = bTmpHead& UART0_TX_BUFFER_MASK;//Store new index 
	  
	  UCSR0B |= (1<<UDRIE0);  //Enable UDRE interrupt 
      
	  while(g_strUart.UART0_TxHead!=g_strUart.UART0_TxTail);//do not continue loop while data in Tx Buf.
	 }
}//end UART0_Transmit


/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_Transmit_Byte
* Input:				byte to transmit
* Output:				void
* Purpose:				this function transmits only one byte data via UART0. 
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_Transmit_Byte(BYTE byData) 
{				

	UDR0 = byData;
    	  	
}//end UART0_Transmit_Byte


/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_DataRegEmptyInterrupt
* Input:				void
* Output:				void
* Purpose:				Tx buffer empty interrupt - this function
						check if there is output data pending and
						sends new byte
*-----------------------------------------------------------------------*/
ISR(USART0_UDRE_vect)
{
	
	BYTE bTmpTail;

	// Check if there is data to be transmitted in Uart0 Tx buffer:
	if (HAL_UART_UART0_DataInTxBuf())
	 {
     
      bTmpTail = (g_strUart.UART0_TxTail+1) & UART0_TX_BUFFER_MASK;// increase buffer index 
	  
	  g_strUart.UART0_TxTail = bTmpTail;    // Store new index 
	  
      UDR0 = g_strUart.UART0_TxBuf[bTmpTail];  // Start transmition 
	 }
	else 
	 UCSR0B &= ~(1<<UDRIE0);         // Disable UDRE interrupt 

}// end UART0_DataRegEmptyInterrupt handler.



/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1Init
* Input:				baud rate
* Output:				void
* Purpose:				This function inits UART0, it sets baud rate,
						enables transmitter and receiver
*-----------------------------------------------------------------------*/
void HAL_UART_UART1Init( unsigned int baudRate )
{
	
	BYTE x;

	g_strUart.UART1_CB_OnRxByte = HAL_UART_UART1_CB_OnRxLocalByte;
	
	#ifdef UART1_DoubleSpeed 
	UCSR1A = (1<<U2X1)
	#endif
	
	// Set UART1 baud rate :
	UBRR1H = (BYTE) (baudRate>>8);                  
	UBRR1L = (BYTE) baudRate;
	
	// Enable UART1 receiver and transmitter,Enable UART1 eceive interrupt(RXCIE1): 
	UCSR1B = (   ( 1 << RXEN1 ) | ( 1 << TXEN1 ) |( 1 << RXCIE1 )); 
	
	UCSR1C = (NumOf_StopBit<<USBS1)|(NumOf_DataBits<<UCSZ10);
	
	// Initialize receive and transmit buffer counters:
	x = 0; 			    

	g_strUart.UART1_RxTail = x;
	g_strUart.UART1_RxHead = x;
	g_strUart.UART1_TxTail = x;
	g_strUart.UART1_TxHead = x;

}//end UART1Init



/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_DataInRxBuf
* Input:				void
* Output:				TRUE/FALSE
* Purpose:				This function checks if there incoming data 
						pending
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART1_DataInRxBuf( void )
{
 return ( g_strUart.UART1_RxHead != g_strUart.UART1_RxTail ); // Return FALSE if the receive 	                                              	 	buffer is empty */
}//end UART1_DataInRxBuf


/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_DataInTxBuf
* Input:				void
* Output:				TRUE/FALSE
* Purpose:				This function checks if there outgoing data 
						pending
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART1_DataInTxBuf( void )
{	
	return ( g_strUart.UART1_TxHead != g_strUart.UART1_TxTail ); // Return 0 (FALSE) if the receive buffer is empty             
}//end UART1_DataInRxBuf



/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_Receive
* Input:				void
* Output:				incoming byte
* Purpose:				This function returns one incoming byte
*-----------------------------------------------------------------------*/
BYTE HAL_UART_UART1_Receive( void )
{
	BYTE bTmpTail;
	
	//while ( g_strUart.UART1_RxHead == g_strUart.UART1_RxTail );//Wait for incomming data(mode 2) 
		
	bTmpTail = ( g_strUart.UART1_RxTail + 1 ) & UART1_RX_BUFFER_MASK; //increase buffer index 
	
	g_strUart.UART1_RxTail = bTmpTail;  // Store new index
	
	return g_strUart.UART1_RxBuf[bTmpTail]; // Return data 
}// end UART1_Receive


/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_RxInterrupt
* Input:				void
* Output:				void
* Purpose:				UART0 Rx interrupt, reads byte from Rx register
						and Calls Rx CB function
*-----------------------------------------------------------------------*/
ISR(USART1_RX_vect)
{	
	BYTE byData;
	
	byData = UDR1; //Read the received data                  
	
	if(g_strUart.UART1_CB_OnRxByte != NULL)
	{
	  g_strUart.UART1_CB_OnRxByte(byData,eHAL_UART_EVENT_UART1_Rx_Event);
	}
}// end UART1_RxInterrupt handler.

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_CB_OnRxLocalByte
* Input:				incoming byte
* Output:				void
* Purpose:				Local CB Rx function - stores the incoming
						byte in local buffer. local buffer can be read
						by HAL_UART_UART0_Receive function
*-----------------------------------------------------------------------*/
void HAL_UART_UART1_CB_OnRxLocalByte(BYTE byData)
{
    BYTE bTmpHead;
	
	bTmpHead = ( g_strUart.UART1_RxHead + 1 ) & UART1_RX_BUFFER_MASK; // increase buffer index 
	 
	g_strUart.UART1_RxHead = bTmpHead; // Store new index    

	if ( bTmpHead == g_strUart.UART1_RxTail )
	{
	 g_strUart.EROR=UART1_RxBuffer_OverFlow; // ERROR! Receive buffer overflow 
	 }
	else // in case buffer is not full
	 g_strUart.UART1_RxBuf[bTmpHead] = byData; // Store received data in buffer
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_SetOnRxByteCB
* Input:				pointer to external CB Rx function
* Output:				void
* Purpose:				Sets pointer to external Rx Callback function
*-----------------------------------------------------------------------*/
void HAL_UART_UART1_SetOnRxByteCB(UART_pfCBOnRxByte pfn)
{
  g_strUart.UART1_CB_OnRxByte = pfn;
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_Transmit
* Input:				pointer to data, length
* Output:				void
* Purpose:				this function transmits data via UART. 
						this function copyes first byte into Tx register,
						enables Tx empty interrupt and waites until the
						whole data will be transmitted
*-----------------------------------------------------------------------*/
void HAL_UART_UART1_Transmit( PBYTE data , WORD length )
{
	volatile BYTE bTmpHead;
	WORD  wTmpLength=0;

	// don't allow UART transmition if now on PLC Studio mode
	if(g_strUart.UART1_CB_OnRxByte(data,eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event))
	{
		return;
	}
	
	bTmpHead = g_strUart.UART1_TxHead ; // get buffer index 
	 
	while(wTmpLength<length)
	 {
	  //internal while loop:			
	  while ((((++bTmpHead)& UART1_TX_BUFFER_MASK) != g_strUart.UART1_TxTail)&&(wTmpLength<length)) 
	   {
	    g_strUart.UART1_TxBuf[bTmpHead& UART1_TX_BUFFER_MASK] = data[wTmpLength++]; // Store data in buffer
	   } 
	  
	  bTmpHead--; // because the  variable is increased and unused on its last loop.       
	  
	  g_strUart.UART1_TxHead =(bTmpHead) & UART1_TX_BUFFER_MASK; //Store new index
	  
	  UCSR1B |= (1<<UDRIE1);  // Enable UDRE interrupt 
    
	  while(g_strUart.UART1_TxHead!=g_strUart.UART1_TxTail);//do not continue loop while data in Tx Buf.
	 }	
}//end UART1_Transmit


 /*----------------------------------------------------------------------
 * Function name:		HAL_UART_UART1_Transmit_Byte
 * Input:				byte to transmit
 * Output:				void
 * Purpose:				this function transmits only one byte data via UART1. 
*-----------------------------------------------------------------------*/
void HAL_UART_UART1_Transmit_Byte(BYTE byData) 
{				
	
	UDR1 = byData;
	
}//end UART1_Transmit_Byte
/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART1_DataRegEmptyInterrupt
* Input:				void
* Output:				void
* Purpose:				Tx buffer empty interrupt - this function
						check if there is output data pending and
						sends new byte
*-----------------------------------------------------------------------*/
ISR(USART1_UDRE_vect)
{
	BYTE bTmpTail;

	if (HAL_UART_UART1_DataInTxBuf()) // Check if all data is transmitted
	 {
	  bTmpTail = (g_strUart.UART1_TxTail+1) & UART1_TX_BUFFER_MASK; // Calculate buffer index 
	  
	  g_strUart.UART1_TxTail = bTmpTail;  // Store new index 
	  
	  UDR1 = g_strUart.UART1_TxBuf[bTmpTail];  // Start transmition 
	 }
	else
	  UCSR1B &= ~(1<<UDRIE1);   // Disable UDRE interrupt 
		
}// end UART1_DataRegEmptyInterrupt handler.




//////////////////////////////////////////////////////////////////////////
// Uart Debug functions - via UART Channel 0
//////////////////////////////////////////////////////////////////////////

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_ShowNum
* Input:				number
* Output:				void
* Purpose:				Show number via UART0 in ASCII format
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_ShowNum(WORD wNum)
{
  BYTE sbyNum[7];
  sprintf((char *)sbyNum,"%u", wNum);
  HAL_UART_UART0_Transmit(sbyNum,strlen((char *)sbyNum));
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_ShowNumHex
* Input:				number
* Output:				void
* Purpose:				Show number via UART0 in ASCII format (HEX)
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_ShowNumHex(WORD wNum)
{
  BYTE sbyNum[7];
  sprintf((char *)sbyNum,"%02X", wNum);
  HAL_UART_UART0_Transmit(sbyNum,strlen((char *)sbyNum));
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_ShowText
* Input:				pointer to string
* Output:				void
* Purpose:				Show string via UART0 in ASCII format
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_ShowText(char * text)
{
  HAL_UART_UART0_Transmit((PBYTE)text, strlen(text));
}

/*----------------------------------------------------------------------
* Function name:		HAL_UART_UART0_NewLine
* Input:				void
* Output:				void
* Purpose:				apply <CR><LF> sequence - UART0
*-----------------------------------------------------------------------*/
void HAL_UART_UART0_NewLine(void)
{
  HAL_UART_UART0_ShowText("\r\n");
}
