#include <HAL_Init.h>



/*----------------------------------------------------------------------
* Function name:		HAL_Init_ConfigureHAL
* Input:				none
* Output:				none
* Purpose:				Init UART and Timer Modules
*-----------------------------------------------------------------------*/
void HAL_Init_ConfigureHAL(void)
{
  BOOL bSuccess = FALSE;

  HAL_Init_Global_Interrupt_Switch(ENABLE); // enable golbal interrupt    
  HAL_Timer_InitTimer0(); 
  HAL_UART_UART0Init(UART0_BaudRate) ;  // inits uart0 with a defined baudrate parameter.
  HAL_UART_UART1Init(UART1_BaudRate) ;  // inits uart1 with a defined baudrate parameter.
  HAL_ExtInt_Init();
}


/*----------------------------------------------------------------------
* Function name:		HAL_Init_Global_Interrupt_Switch
* Input:				Global Interrupt - ENABLED/DISABLED
* Output:				none
* Purpose:				Set Global Interrupt Status
*-----------------------------------------------------------------------*/
void HAL_Init_Global_Interrupt_Switch(BOOL status)
{
 if (status==ENABLE)
 	sei(); // enable global interrupt
 else
 	cli(); // disable global interrupt

}// end Global_Interrupt_Switch function
