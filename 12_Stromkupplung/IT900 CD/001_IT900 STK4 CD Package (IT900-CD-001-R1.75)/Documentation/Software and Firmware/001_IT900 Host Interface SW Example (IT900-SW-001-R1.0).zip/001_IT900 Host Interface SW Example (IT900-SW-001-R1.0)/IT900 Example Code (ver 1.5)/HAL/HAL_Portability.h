

#ifndef ScpPortability_IT_03333334444444444433221
#define ScpPortability_IT_03333334444444444433221


#ifndef NULL
#define NULL  0
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE  1
#endif

#define ENABLE  1
#define DISABLE 0

#define FULL  1
#define EMPTY 0

#define ON	  1
#define OFF	  0

#define STOP   0
#define START  1

#define PASS    	1
#define FAIL        0

typedef unsigned char  	   BYTE; 
typedef unsigned short int WORD;
typedef unsigned long int  DWORD;
typedef BYTE 	 	   	   BOOL;

		
typedef char               *PCHAR;
typedef BYTE               *PBYTE;
typedef BOOL		       *PBOOL;
typedef WORD               *PWORD;
typedef DWORD			   *PDWORD;
typedef int                *PINT;

#endif
