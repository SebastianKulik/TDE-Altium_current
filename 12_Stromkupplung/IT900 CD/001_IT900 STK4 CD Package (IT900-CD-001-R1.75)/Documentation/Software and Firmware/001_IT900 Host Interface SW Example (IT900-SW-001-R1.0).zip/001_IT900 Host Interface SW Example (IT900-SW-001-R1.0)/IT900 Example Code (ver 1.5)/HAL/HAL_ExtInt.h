/*----------------------------------------------------------------------
*	Author		: Tsirlin Alexey
*	Copyright	: (c)2005 Yitran Communications Ltd.
*	Description	: HAL External Interrupts Module for ATMEGA64/128
*-----------------------------------------------------------------------
* Revision list
*-----------------------------------------------------------------------
*	Version	Author	Date		Changes
*	  0.1	Alexey	03/11/06	Started design
*-----------------------------------------------------------------------*/
#ifndef HAL_EXT_INT_H
#define HAL_EXT_INT_H

#ifdef  HAL_EXT_INT_H_MAIN_FILE
#define	HAL_EXT_INT_H_EXT
#else
#define	HAL_EXT_INT_H_EXT	extern
#endif

#include <HAL_UART.h>
#include <HAL_Timer.h>
#include <HAL_IO.h>
#include <string.h>
#include <avr/interrupt.h>


/////////////////////////////////////
// Struct and Typedef Declarations //
/////////////////////////////////////
typedef void(*pfnOnExtIntCBFunc)(void);

#define HAL_EXT_INT_NUM_OF_EXT_INTS			8

typedef enum _HAL_EXT_INT_TYPE
{
	eHAL_EXT_INT_TYPE_LOW_LEVEL = 0,
	eHAL_EXT_INT_TYPE_DISABLED,
	eHAL_EXT_INT_TYPE_FALLING,
	eHAL_EXT_INT_TYPE_RISING
}HAL_EXT_INT_TYPE;

#define HAL_EXT_INT_0_SHIFT			0
#define HAL_EXT_INT_0_MASK			(0x03 << HAL_EXT_INT_0_SHIFT)

#define HAL_EXT_INT_1_SHIFT			2
#define HAL_EXT_INT_1_MASK			(0x03 << HAL_EXT_INT_1_SHIFT)

#define HAL_EXT_INT_2_SHIFT			4
#define HAL_EXT_INT_2_MASK			(0x03 << HAL_EXT_INT_2_SHIFT)

#define HAL_EXT_INT_3_SHIFT			6
#define HAL_EXT_INT_3_MASK			(0x03 << HAL_EXT_INT_3_SHIFT)

#define HAL_EXT_INT_4_SHIFT			0
#define HAL_EXT_INT_4_MASK			(0x03 << HAL_EXT_INT_4_SHIFT)

#define HAL_EXT_INT_5_SHIFT			2
#define HAL_EXT_INT_5_MASK			(0x03 << HAL_EXT_INT_5_SHIFT)

#define HAL_EXT_INT_6_SHIFT			4
#define HAL_EXT_INT_6_MASK			(0x03 << HAL_EXT_INT_6_SHIFT)

#define HAL_EXT_INT_7_SHIFT			6
#define HAL_EXT_INT_7_MASK			(0x03 << HAL_EXT_INT_7_SHIFT)

#define HAL_EXT_INT_0_PORT			ePortD
#define HAL_EXT_INT_0_PIN			0

#define HAL_EXT_INT_1_PORT			ePortD
#define HAL_EXT_INT_1_PIN			1

#define HAL_EXT_INT_2_PORT			ePortD
#define HAL_EXT_INT_2_PIN			2

#define HAL_EXT_INT_3_PORT			ePortD
#define HAL_EXT_INT_3_PIN			3

#define HAL_EXT_INT_4_PORT			ePortE
#define HAL_EXT_INT_4_PIN			4

#define HAL_EXT_INT_5_PORT			ePortE
#define HAL_EXT_INT_5_PIN			5

#define HAL_EXT_INT_6_PORT			ePortE
#define HAL_EXT_INT_6_PIN			6

#define HAL_EXT_INT_7_PORT			ePortE
#define HAL_EXT_INT_7_PIN			7


													 
///////////////////////////
// Function Declarations //
///////////////////////////
HAL_EXT_INT_H_EXT void HAL_ExtInt_Arm(BYTE byIntNum, BYTE byMode);
HAL_EXT_INT_H_EXT void HAL_ExtInt_SetCBPfn(BYTE byIntNum, pfnOnExtIntCBFunc pFunc);
HAL_EXT_INT_H_EXT void HAL_ExtInt_Init(void);

/*#pragma interrupt_handler HAL_ExtInt_Int0:iv_INT0 
#pragma interrupt_handler HAL_ExtInt_Int1:iv_INT1 
#pragma interrupt_handler HAL_ExtInt_Int2:iv_INT2 
#pragma interrupt_handler HAL_ExtInt_Int3:iv_INT3 
#pragma interrupt_handler HAL_ExtInt_Int4:iv_INT4 
#pragma interrupt_handler HAL_ExtInt_Int5:iv_INT5 
#pragma interrupt_handler HAL_ExtInt_Int6:iv_INT6 
#pragma interrupt_handler HAL_ExtInt_Int7:iv_INT7 */

///////////////////////////////////
// Global module vars definition //
///////////////////////////////////

#ifdef HAL_EXT_INT_H_MAIN_FILE
pfnOnExtIntCBFunc g_HAL_ExtInt_psCBFunc[HAL_EXT_INT_NUM_OF_EXT_INTS];
#endif // end HAL_EXT_INT_H_MAIN_FILE

#endif // end HAL_EXT_INT_H
