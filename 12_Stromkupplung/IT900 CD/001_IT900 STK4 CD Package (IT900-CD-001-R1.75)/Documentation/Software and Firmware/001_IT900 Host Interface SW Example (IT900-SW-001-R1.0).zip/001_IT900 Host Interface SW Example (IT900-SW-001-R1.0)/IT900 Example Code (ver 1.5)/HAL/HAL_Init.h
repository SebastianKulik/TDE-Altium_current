#if !defined(HALINTSWITCH_73487476)
#define HALINTSWITCH_73487476

#include <HAL_UART.h>
#include <HAL_Timer.h>
#include <HAL_IO.h>
#include <HAL_Portability.h>
#include <io.h>
#include <HAL_ExtInt.h>


/* Prototypes */
void HAL_Init_InitHAL(void);
void HAL_Init_ConfigureHAL(void);
void HAL_Init_Global_Interrupt_Switch(BOOL status);// ENABLE/DISABLE

#endif

