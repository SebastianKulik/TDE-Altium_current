#include <UARTHandler.h>

// Enter PLC Studio Command
const BYTE g_sbyEnterStudioModeCode_hex[] = {0x14, 0x15, 0x92, 0x65, 0x35, 0x89, 0x79, 0x32, 0x38, 0x46, 0x26, 0x43, 0x38, 0x82,0x79};

// Exit PLC Studio Command
const BYTE g_sbyLeavePLCStudioModeCode_hex[] = {0x50, 0x28, 0x88, 0x41, 0x97, 0x16, 0x93, 0x99, 0x37,0x51, 0x5, 0x82, 0x20, 0x97,0x49, 0x44};

/*----------------------------------------------------------------------
 * Function name:	UARTHandler_Init
 * Input:			void
 * Output:			void
 * Purpose:			Init UART Handler:
					Init UARTHandler variables
					Set UART0/UART1 CB Rx Functions
*-----------------------------------------------------------------------*/
void UARTHandler_Init(void)
{
	// init to IDLE state
	g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_APPLICATION_RUNNING;
	// init current byte to 0
	g_UART_Handler_struct.byCurrent_Index = 0;

	// set pointer to incoming data CB function:
	HAL_UART_UART0_SetOnRxByteCB(UARTHandler_CB_OnRxByte);
	HAL_UART_UART1_SetOnRxByteCB(UARTHandler_CB_OnRxByte);
}


/*----------------------------------------------------------------------
* Function name:	UARTHandler_CB_OnRxByte
* Input:			byData  - received byte from one of the UARTs,
					byEvent - byte which indicates who call the function (UART0 or UART1)
* Output:			return 1, if running on PLC Studio mode.
					return 0, if running on Application mode.
* Purpose:			This function handles the state machine:
					UART0_RX_EVENT (get byte from PC)
						Application mode: do nothing.
						PLC Studio mode: transmit byte to UART1
					UART1_RX_EVENT (get byte form Modem)
						Application mode: call PLCModemDriver_CB_OnRxByte
						PLC Studio mode: transmit byte to UART0
*-----------------------------------------------------------------------*/
BOOL UARTHandler_CB_OnRxByte(BYTE byData, BYTE byEvent)
{

	// checks the RX state
	switch(g_UART_Handler_struct.byRxState)
	{

		// IDLE state: original Application is running
		case (eUART_HANDLER_RX_STATES_APPLICATION_RUNNING):

			// checks what is the event that call the UARTHandler_CB_OnRxByte (UART0_Rx or UART1_Rx)
			switch(byEvent)
			{
				// the Event was UART0_Rx
				case (eHAL_UART_EVENT_UART0_Rx_Event):

					// checks if the received byte is the first byte of the "Enter" command
					if(byData==g_sbyEnterStudioModeCode_hex[0])
					{
						// update current index
						g_UART_Handler_struct.byCurrent_Index++;
						// move to Application running and decoding State
						g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_APPLICATION_RUNNING_AND_DECODING;
					}

					/* TODO: Call interface application handler
					         (in this example � do nothing)
					else
					{

					}
					*/

					break;

				// the Event was UART1_Rx
				case (eHAL_UART_EVENT_UART1_Rx_Event):

					// call the PLCModemDriver to handle the received byte
					PLCModemDriver_CB_OnRxByte(byData);
					break;

				// the Event was Application UART0_Tx
				case(eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event):

					// do nothing
					break;

				// the Event was Application UART1_Tx
				case(eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event):

					// do nothing
					break;

				default:
					// call the PLCModemDriver to handle the received byte
					PLCModemDriver_CB_OnRxByte(byData);
					break;

			}
			// flags the Transmit function, that the system is now running
			// on application mode - Application Tx transmition on UART is allowed.
			return 0;
			break;


		// state: original Application is running and decoding
		//		  the "Enter" to PLC Studio Application command
		case (eUART_HANDLER_RX_STATES_APPLICATION_RUNNING_AND_DECODING):

			// checks what is the event that call the UARTHandler_CB_OnRxByte (UART0_Rx or UART1_Rx)
			switch(byEvent)
			{

			// the Event was UART0_Rx
			case (eHAL_UART_EVENT_UART0_Rx_Event):

				// does the received byte is equal to the "Enter Studio" command byte in the "byIndex" place ?
				if(byData==g_sbyEnterStudioModeCode_hex[g_UART_Handler_struct.byCurrent_Index])
				{
					// update current index
					g_UART_Handler_struct.byCurrent_Index++;

					// does the current index is equal the "Enter Studio" command size ?
					if(g_UART_Handler_struct.byCurrent_Index==ENTER_STUDIO_MODE_COMMAND_SIZE)
					{
						// clear index
						g_UART_Handler_struct.byCurrent_Index = 0;
						// move to PLC Studio running state
						g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_PLCS_RUNNING;
					}
				}

				else
				{
					// clear index
					g_UART_Handler_struct.byCurrent_Index = 0;
					// move to Application running state
					g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_APPLICATION_RUNNING;
				}

				break;

			// the Event was UART1_Rx
			case (eHAL_UART_EVENT_UART1_Rx_Event):

				// call the PLCModemDriver to handle the received byte
				PLCModemDriver_CB_OnRxByte(byData);
				break;

			// the Event was Application UART0_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event):

				// do nothing
				break;

			// the Event was Application UART1_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event):

				// do nothing
					break;

			default:
				// call the PLCModemDriver to handle the received byte
				PLCModemDriver_CB_OnRxByte(byData);

			}
			// flags the Transmit function, that the system is now running
			// on application mode - ApplicationTx transmition on UART is allowed.
			return 0;
			break;


		// state: PLC Studio Application is running
		case (eUART_HANDLER_RX_STATES_PLCS_RUNNING):

			// checks what is the event that call the UARTHandler_CB_OnRxByte (UART0_Rx or UART1_Rx)
			switch(byEvent)
			{

			// the Event was UART0_Rx
			case (eHAL_UART_EVENT_UART0_Rx_Event):

				// checks if the received byte is the first byte of the "Exit" command
				if(byData==g_sbyLeavePLCStudioModeCode_hex[0])
				{
					// update current index
					g_UART_Handler_struct.byCurrent_Index++;
					// move to PLC Studio running and decoding state
					g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_PLCS_RUNNING_AND_DECODING;
					// send byte to UART1
					HAL_UART_UART1_Transmit_Byte(byData); // sending only one byte
				}

				// send byte to UART1
				else
				{
					HAL_UART_UART1_Transmit_Byte(byData); // sending only one byte
				}

				break;

			// the Event was UART1_Rx
			case (eHAL_UART_EVENT_UART1_Rx_Event):

				// send byte to UART0
					HAL_UART_UART0_Transmit_Byte(byData); // sending only one byte
				break;

			// the Event was Application UART0_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event):

				// do nothing
				break;

			// the Event was Application UART1_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event):

				// do nothing
					break;

			//default:

			}
			// flags the Transmit function, that the system is now running
			// on PLC Studio mode - Application Tx transmition on UART isn't allowed.
			return 1;
			break;


		// state: PLC Studio Application is running and decoding
	    //        the "Exit" from PLC Studio Application command
		case (eUART_HANDLER_RX_STATES_PLCS_RUNNING_AND_DECODING):

			// checks what is the event that call the UARTHandler_CB_OnRxByte (UART0_Rx or UART1_Rx)
			switch(byEvent)
			{

			// the Event was UART0_Rx
			case (eHAL_UART_EVENT_UART0_Rx_Event):

				// does the received byte is equal to the "Exit Studio" command byte in the "byIndex" place ?
				if(byData==g_sbyLeavePLCStudioModeCode_hex[g_UART_Handler_struct.byCurrent_Index])
				{
					// update current index
					g_UART_Handler_struct.byCurrent_Index++;

					// does the current byte index is equal the "Exit Studio" command size ?
					if(g_UART_Handler_struct.byCurrent_Index==EXIT_STUDIO_MODE_COMMAND_SIZE)
					{
						// clear index
						g_UART_Handler_struct.byCurrent_Index = 0;
						// move to Application running state
						g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_APPLICATION_RUNNING;
					}

					// send byte to UART1
					else
					{
						HAL_UART_UART1_Transmit_Byte(byData); // sending only one byte
					}
				}

				else
				{
					// clear index
					g_UART_Handler_struct.byCurrent_Index = 0;
					// move to PLC Studio running state
					g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_PLCS_RUNNING;

					// send byte to UART1
						HAL_UART_UART1_Transmit_Byte(byData); // sending only one byte
				}

				break;

			// the Event was UART1_Rx
			case (eHAL_UART_EVENT_UART1_Rx_Event):

				// send byte to UART0
					HAL_UART_UART0_Transmit_Byte(byData); // sending only one byte
				break;

			// the Event was Application UART0_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event):

				// do nothing
				break;

			// the Event was Application UART1_Tx
			case(eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event):

				// do nothing
					break;

			//default:

			}
			// flags the Transmit function, that the system is now running
			// on PLC Studio mode - Application Tx transmition on UART isn't allowed.
			return 1;
			break;


		// state: unknown state --> back to IDLE
		default:
			g_UART_Handler_struct.byRxState = eUART_HANDLER_RX_STATES_APPLICATION_RUNNING;
	}

}




