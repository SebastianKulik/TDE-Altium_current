#define HAL_EXT_INT_H_MAIN_FILE
#include <HAL_ExtInt.h>

void HAL_ExtInt_Init(void)
{
	memset(g_HAL_ExtInt_psCBFunc, 0, sizeof(g_HAL_ExtInt_psCBFunc) * HAL_EXT_INT_NUM_OF_EXT_INTS);
}

void HAL_ExtInt_Arm(BYTE byIntNum, BYTE byMode)
{
	switch(byIntNum)
	{
		case 0:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRA &= ~(HAL_EXT_INT_0_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_0_PORT,
						HAL_EXT_INT_0_PIN,
						IN,
						TRUE
					);
				EICRA |= (byMode << HAL_EXT_INT_0_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 1:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRA &= ~(HAL_EXT_INT_1_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_1_PORT,
						HAL_EXT_INT_1_PIN,
						IN,
						TRUE
					);
				EICRA |= (byMode << HAL_EXT_INT_1_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 2:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRA &= ~(HAL_EXT_INT_2_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_2_PORT,
						HAL_EXT_INT_2_PIN,
						IN,
						TRUE
					);
				EICRA |= (byMode << HAL_EXT_INT_2_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 3:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRA &= ~(HAL_EXT_INT_3_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_3_PORT,
						HAL_EXT_INT_3_PIN,
						IN,
						TRUE
					);
				EICRA |= (byMode << HAL_EXT_INT_3_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 4:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRB &= ~(HAL_EXT_INT_4_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_4_PORT,
						HAL_EXT_INT_4_PIN,
						IN,
						TRUE
					);
				EICRB |= (byMode << HAL_EXT_INT_4_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 5:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRB &= ~(HAL_EXT_INT_5_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_5_PORT,
						HAL_EXT_INT_5_PIN,
						IN,
						TRUE
					);
				EICRB |= (byMode << HAL_EXT_INT_5_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 6:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRB &= ~(HAL_EXT_INT_6_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_6_PORT,
						HAL_EXT_INT_6_PIN,
						IN,
						TRUE
					);
				EICRB |= (byMode << HAL_EXT_INT_6_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;
		case 7:
			EIMSK &= ~(1<<byIntNum);		// disable interrupt
			if(byMode != eHAL_EXT_INT_TYPE_DISABLED)
			{
				EICRB &= ~(HAL_EXT_INT_7_MASK);
				HAL_IO_togglePin
					(
						HAL_EXT_INT_7_PORT,
						HAL_EXT_INT_7_PIN,
						IN,
						TRUE
					);
				EICRB |= (byMode << HAL_EXT_INT_7_SHIFT);
				EIFR |= (1<<byIntNum);
				EIMSK |= (1<<byIntNum);
			}
			break;

	}
}

void HAL_ExtInt_SetCBPfn(BYTE byIntNum, pfnOnExtIntCBFunc pFunc)
{
	g_HAL_ExtInt_psCBFunc[byIntNum] = pFunc;
}


//void HAL_ExtInt_Int0(void)
ISR(INT0_vect)
{
	if(g_HAL_ExtInt_psCBFunc[0])
	{
		g_HAL_ExtInt_psCBFunc[0]();
	}
}

//void HAL_ExtInt_Int1(void)
ISR(INT1_vect)
{
	if(g_HAL_ExtInt_psCBFunc[1])
	{
		g_HAL_ExtInt_psCBFunc[1]();
	}
}

//void HAL_ExtInt_Int2(void)
ISR(INT2_vect)
{
	if(g_HAL_ExtInt_psCBFunc[2])
	{
		g_HAL_ExtInt_psCBFunc[2]();
	}
}

//void HAL_ExtInt_Int3(void)
ISR(INT3_vect)
{
	if(g_HAL_ExtInt_psCBFunc[3])
	{
		g_HAL_ExtInt_psCBFunc[3]();
	}
}

//void HAL_ExtInt_Int4(void)
ISR(INT4_vect)
{
	if(g_HAL_ExtInt_psCBFunc[4])
	{
		g_HAL_ExtInt_psCBFunc[4]();
	}
}

//void HAL_ExtInt_Int5(void)
ISR(INT5_vect)
{
	if(g_HAL_ExtInt_psCBFunc[5])
	{
		g_HAL_ExtInt_psCBFunc[5]();
	}
}

//void HAL_ExtInt_Int6(void)
ISR(INT6_vect)
{
	if(g_HAL_ExtInt_psCBFunc[6])
	{
		g_HAL_ExtInt_psCBFunc[6]();
	}
}

//void HAL_ExtInt_Int7(void)
ISR(INT7_vect)
{
	if(g_HAL_ExtInt_psCBFunc[7])
	{
		g_HAL_ExtInt_psCBFunc[7]();
	}
}
