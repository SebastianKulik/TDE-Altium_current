/*----------------------------------------------------------------------
*	Author		: Joseph Ben-Atiya
*	Copyright	: (c)2011 Yitran Communications Ltd.
*	Description	: UART Handler Header file
*-----------------------------------------------------------------------
* Revision list
*-----------------------------------------------------------------------
*	Version	Author	Date		Changes
*	  1.0	Joseph	18/12/11	Started design
*-----------------------------------------------------------------------*/

#include <HAL_UART.h>
#include <HAL_Timer.h>
#include <HAL_IO.h>


/////////////////////////////////////
// Struct and Typedef Declarations //
/////////////////////////////////////

// defines the UART_HANDLER buffer max size
#define UART_HANDLER_BUFFER_SIZE         16

// defines the Studio mode Command size
#define ENTER_STUDIO_MODE_COMMAND_SIZE   15
#define EXIT_STUDIO_MODE_COMMAND_SIZE    16

// defines mask bits
#define MASK_ALL 0x00

typedef struct _UART_HANDLER_STR
{
    // the current index of the received byte
	BYTE byCurrent_Index;
	// indicates the currents state in the state machine 
	BYTE byRxState;
}
UART_HANDLER_STR;

typedef enum _UART_HANDLER_RX_STATES
{
	eUART_HANDLER_RX_STATES_APPLICATION_RUNNING = 0,
	eUART_HANDLER_RX_STATES_APPLICATION_RUNNING_AND_DECODING,
	eUART_HANDLER_RX_STATES_PLCS_RUNNING,
	eUART_HANDLER_RX_STATES_PLCS_RUNNING_AND_DECODING
}
UART_HANDLER_RX_STATES;


///////////////////////////
// Function Declarations //
///////////////////////////

void UARTHandler_Init(void);
BOOL UARTHandler_CB_OnRxByte(BYTE byData, BYTE byEvent);

///////////////////////////////////
// Global module vars definition //
///////////////////////////////////


UART_HANDLER_STR g_UART_Handler_struct;


