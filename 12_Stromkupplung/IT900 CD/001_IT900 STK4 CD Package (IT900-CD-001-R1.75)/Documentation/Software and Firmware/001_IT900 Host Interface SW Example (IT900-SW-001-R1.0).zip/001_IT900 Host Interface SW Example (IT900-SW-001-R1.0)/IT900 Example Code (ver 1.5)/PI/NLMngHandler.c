#define NLMNGHANDLER_H_MAIN_FILE
#include <NLMNGHandler.h>

// list of approved stations' SNs (LSB FIRST)
// Those SNs should be changed to match the SNs of RMTs
const BYTE sbyApprovedSNs[NLMNG_SN_LIST_SIZE][NLMNG_SN_SIZE]=
{
  {
    0x04,0x54,0x00,0x56,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
  },
  {
    0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
  }
};

/*----------------------------------------------------------------------
* Function name:	NLMngHandler_bEnableNLMng
* Input:			NLMng enable/disable
* Output:			Success Indication
* Purpose:			Enable/disable NLMng module in PLCModemNL. In case the
*					parameter is changed - save parameters table in NVM
*-----------------------------------------------------------------------*/
BOOL NLMngHandler_bEnableNLMng(BOOL bEnable)
{
  WORD wCurrent;
  BOOL bSuccess = TRUE;
  if(PLCModemDriver_bGetParam(&wCurrent, NLParDef_eIdx_NLMngEnabled, HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS))
  {
    // read current 'NLMng enable flag' status
	  if((WORD)bEnable != wCurrent)
	  {
	    // set new 'NLMng enable flag' status if it is not match
	    bSuccess =
	      PLCModemDriver_bSetParam // set 'NLMng enbaled' parameter in NL settings
		    (
		      (WORD)bEnable,
			  NLParDef_eIdx_NLMngEnabled,
			  HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
		    );

	    if(bSuccess)
	    {
	      // save parameters to NVM
			bSuccess = PLCModemDriver_bSaveParameters();
			bSuccess = PLCModemDriver_bReset_PIM_SW();   // this parameter requires modem reset
	    }

	  }
  }
  return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	NLMngHandler_MessageHandler
* Input:			pointer to data, length, Opcode
* Output:			void
* Purpose:			parse NLMng messages. If message requires further parsing
*					copy the message to the sbyNLMngIncomingBuffer, otherwise
*					perform an immediate action and release the buffer
*-----------------------------------------------------------------------*/
void NLMngHandler_MessageHandler(PBYTE pbyData, WORD wLength, BYTE byOpcode)
{
	// check message subtype
	switch(byOpcode)
	{
		case(eHOST_EI_SERVICE_SUBTYPES_MANAGMENT_SA_CONNECTED_TO_NC_I):
			// set connected to BS flag
			g_NLMngHandler_struct.bConnectedToNC = TRUE;
			break;

		case(eHOST_EI_SERVICE_SUBTYPES_MANAGMENT_SA_DISCONNECTED_FROM_NC_I):
			// clear connected to BS flag
			g_NLMngHandler_struct.bConnectedToNC = FALSE;
			break;

		case(eHOST_EI_SERVICE_SUBTYPES_MANAGMENT_SA_GET_ADMISSION_REQ_I):
			// do not accept next packet, if previous one was not parsed
			if(g_NLMngHandler_struct.wNLMngIncomingBufferLength)
			{
				return;
			}
			// set admission request flag - copy packet to in buffer
			g_NLMngHandler_struct.bAdmissionRequest = TRUE;
			memcpy(g_NLMngHandler_struct.sbyNLMngIncomingBuffer, pbyData, wLength);
			g_NLMngHandler_struct.wNLMngIncomingBufferLength = wLength;
			break;

		case(eHOST_EI_SERVICE_SUBTYPES_MANAGMENT_SA_NETWORK_ID_ASSIGNED_I):
			// Set Network Address Assigned Flag
			g_NLMngHandler_struct.bNetworkAddressAssigned = TRUE;
			break;

		default:
			// release packet - if ID unknown
			NLMngHandler_ClearIncomingPacketBuffer();
			break;
	}
}

/*----------------------------------------------------------------------
* Function name:	NLMngHandler_ClearIncomingPacketBuffer
* Input:			void
* Output:			void
* Purpose:			reset NLMng message received
*-----------------------------------------------------------------------*/
void NLMngHandler_ClearIncomingPacketBuffer(void)
{
  g_NLMngHandler_struct.wNLMngIncomingBufferLength = 0;
}

/*----------------------------------------------------------------------
* Function name:	NLMngHandler_Init
* Input:			void
* Output:			void
* Purpose:			Init NLMng handler
*-----------------------------------------------------------------------*/
void NLMngHandler_Init(void)
{
  g_NLMngHandler_struct.wNLMngIncomingBufferLength = 0;
  g_NLMngHandler_struct.bConnectedToNC = FALSE;
  g_NLMngHandler_struct.bAdmissionRequest = FALSE;
  g_NLMngHandler_struct.bNetworkAddressAssigned = FALSE;
}



/*----------------------------------------------------------------------
* Function name:	NLMngHandler_bIsConnectedToBase
* Input:			void
* Output:			BS status
* Purpose:			return connected to NC (base) status (TRUE/FALSE)
*-----------------------------------------------------------------------*/
BOOL NLMngHandler_bIsConnectedToBase(void)
{
	return(g_NLMngHandler_struct.bConnectedToNC);
}

/*----------------------------------------------------------------------
* Function name:	NLMngHandler_bIsNetIDAssigned
* Input:			void
* Output:			Net ID Assigned status
* Purpose:			return Net ID Assigned Status
*-----------------------------------------------------------------------*/
BOOL NLMngHandler_bIsNetIDAssigned(void)
{
	return(g_NLMngHandler_struct.bNetworkAddressAssigned);
}



/*----------------------------------------------------------------------
* Function name:	bSNInList
* Input:			pointer to SN
* Output:			TRUE if the SN exists in the list, FALSE otherwise
* Purpose:			check if SN of the remote meter exists
*					in the approve list of the NC
*-----------------------------------------------------------------------*/
BOOL bSNInList(PBYTE pbyData)
{
  BYTE i,j;
  for(i=0;i<NLMNG_SN_LIST_SIZE;i++)
  {
    for(j=0;j<NLMNG_SN_SIZE;j++)
	  {
	    if(pbyData[j] != sbyApprovedSNs[i][j])
	      break; // no match - move to next SN
	  }
	  if(j == NLMNG_SN_SIZE)
	  {
	    return TRUE; // SN match
	  }
  }
  return FALSE;
}

/*----------------------------------------------------------------------
* Function name:	CheckAdmission
* Input:			void
* Output:			void
* Purpose:			Parse admission request (valid for NC only).
					This function checks SN of the RS in the Database
					and transmits APPROVE or REFUSE response
*-----------------------------------------------------------------------*/
void CheckAdmission(void)
{
	WORD wAdmissionResult = NLMNG_EI_DB_ADMISSION_RES_REFUSED;
	if(bSNInList(g_NLMngHandler_struct.sbyNLMngIncomingBuffer))
	{
		wAdmissionResult = NLMNG_EI_DB_ADMISSION_RES_APPROVED;
//		HAL_UART_UART0_ShowText("Approved\r\n");
	}
	else
	{
//		HAL_UART_UART0_ShowText("Refused\r\n");
	}

	// send admission response to PLCModem
	PLCModemDriver_bSendAdmissionResponse
		(
			wAdmissionResult,
			g_NLMngHandler_struct.sbyNLMngIncomingBuffer,
			g_NLMngHandler_struct.wNLMngIncomingBufferLength
		);
}


/*----------------------------------------------------------------------
* Function name:	NLMngHandler_ManageNLMng
* Input:			void
* Output:			void
* Purpose:			manage NLMng - called from main loop. This function
					Checks if there is Admission request and
					handles it. Afterward the function releases
					incoming buffer
*-----------------------------------------------------------------------*/
void NLMngHandler_ManageNLMng(void)
{
  // check if there is admission request pending (for NC only)
  if(g_NLMngHandler_struct.bAdmissionRequest)
  {
	  CheckAdmission(); //prepare answer packet
	  NLMngHandler_ClearIncomingPacketBuffer(); // release NLMng receiver
	  g_NLMngHandler_struct.bAdmissionRequest = FALSE;
  }
}





//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

// Service Functions

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

/*----------------------------------------------------------------------
* Function name:	dwStringToDWORD
* Input:			pointer to data
* Output:			DWORD
* Purpose:			convert 4 bytes to DWORD
*-----------------------------------------------------------------------*/
DWORD dwStringToDWORD(PBYTE pbyData)
{
  DWORD dwResult;
  dwResult = (DWORD)pbyData[0];
  dwResult += ((DWORD)pbyData[1] << 8);
  dwResult += ((DWORD)pbyData[2] << 16);
  dwResult += ((DWORD)pbyData[3] << 24);
  return dwResult;
}

/*----------------------------------------------------------------------
* Function name:	DWORDToString
* Input:			pointer to data, number
* Output:			void
* Purpose:			convert DWORD to 4 bytes
*-----------------------------------------------------------------------*/
void DWORDToString(PBYTE pbyData, DWORD dwNum)
{
  pbyData[0] = (BYTE)(dwNum & 0xff);
  pbyData[1] = (BYTE)(dwNum >> 8);
  pbyData[2] = (BYTE)(dwNum >> 16);
  pbyData[3] = (BYTE)(dwNum >> 24);
}
