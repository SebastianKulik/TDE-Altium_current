#if !defined(_INPUT_OUTPUT_002983834784_)
#define _INPUT_OUTPUT_002983834784_

#include <io.h>
#include <HAL_Portability.h>


// Defines:
typedef
  enum tagePort_t
    {
	ePortF	 				= 5,  // PortF 
	ePortG					= 6,  // PortG 
	eDummy					= 7,  
    ePortA		            = 0,  // PortA 
    ePortB					= 1,  // PortB 
    ePortC					= 2,  // PortC 
    ePortD					= 3,  // PortD 
	ePortE					= 4   // PortE
    } ePort_t;

// Pin Description:

#define PIM_RESET_PIN		 2
#define PIM_RESET_PORT		 ePortA

#define DBG_LED_RED_PIN		 1
#define DBG_LED_RED_PORT	 ePortA

#define DBG_LED_GREEN_PIN	 0
#define DBG_LED_GREEN_PORT	 ePortA

// Ports Direction
#define INPUT  0
#define OUTPUT 1



#define IN 	  		0
#define OUT	  		1
#define NOPULL		0
#define PULLUP 		1
#define CLEAR		0
#define SET			1


/* Prototypes */
extern BYTE HAL_IO_getPort(ePort_t ePort);
extern void HAL_IO_togglePin(ePort_t ePort,BYTE pin,BYTE direction, BYTE pullOrOutput);
extern void HAL_IO_TurnOnRed(void);
extern void HAL_IO_TurnOnGreen(void);
extern void HAL_IO_TurnOffRed(void);
extern void HAL_IO_TurnOffGreen(void);
extern void HAL_IO_SetModemBaudRate(void);


#endif
