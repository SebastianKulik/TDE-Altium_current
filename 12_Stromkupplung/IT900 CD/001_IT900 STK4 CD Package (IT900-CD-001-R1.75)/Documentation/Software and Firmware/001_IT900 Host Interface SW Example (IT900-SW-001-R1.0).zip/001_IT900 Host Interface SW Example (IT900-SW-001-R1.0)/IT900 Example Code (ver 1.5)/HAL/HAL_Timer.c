#include <HAL_Timer.h>


// when the start value of the overflow buffer is set to 0 and the
// clock devision is clk/1024(crystal=3.6864M) - one timer tick equals about 71 ms

volatile WORD Timer0_Ticks;  // This variable will increase itself with
volatile WORD Timer0_Activity_Counter;	// This variable used for PLCModem activity counter
		 	 			    // every overflow0 interrupt.

/*----------------------------------------------------------------------
* Function name:		HAL_Timer_InitTimer0
* Input:				void
* Output:				void
* Purpose:				Init HAL_Timer module and Timer0
*-----------------------------------------------------------------------*/
void HAL_Timer_InitTimer0(void)
{
	TIMSK|=0x01; // Enable overflow interrupt
	Timer0_Ticks = 0; //set the counter to 0.
	Timer0_Activity_Counter = 0;
	TCCR0 = HAL_TIMER_NO_CLOCK;       //stop. no clock source
	TCNT0 = 0;     //set count (start value)
}// end InitTimer0


/*----------------------------------------------------------------------
* Function name:		HAL_Timer_StartTimer0
* Input:				Count start value, Timer mode
* Output:				void
* Purpose:				init timer 0. Possible modes:
						0x00= clock stop
						0x01= no prescaling
						0x02= clock/8    (From prescaler)
						0x03= clock/32	 (From prescaler)
						0x04= clock/64	 (From prescaler)
						0x05= clock/128	 (From prescaler)
						0x06= clock/256	 (From prescaler)
						0x07= clock/1024 (From prescaler)
* in mode 7 - one timer tick (0-255) equals about 71 ms
*-----------------------------------------------------------------------*/
void HAL_Timer_StartTimer0(BYTE startValue,BYTE prescaling)
{
	TCNT0 = startValue;     //set count (start value)
	TCCR0 = prescaling;
}//end StartTimer0


/*----------------------------------------------------------------------
* Function name:		HAL_Timer_StopTimer0
* Input:				void
* Output:				void
* Purpose:				Stop Timer 0
*-----------------------------------------------------------------------*/
void HAL_Timer_StopTimer0()
{
	TCCR0 = HAL_TIMER_NO_CLOCK;//stop. no clock source
	Timer0_Ticks=0;
}



/*----------------------------------------------------------------------
* Function name:		Timer0_OverflowInterrupt
* Input:				void
* Output:				void
* Purpose:				timer 0 overflow interrupt function -
						increase Timer0_Tick variable every timer
						tick
*-----------------------------------------------------------------------*/
ISR(TIMER0_OVF_vect)
{
	Timer0_Ticks++;	
	Timer0_Activity_Counter++;
} // end Timer0_OverflowInterrupt


/*----------------------------------------------------------------------
* Function name:		HAL_Timer_iGetTimer0Ticks
* Input:				void
* Output:				timer 0 ticks counter
* Purpose:				return timer 0 ticks counter
*-----------------------------------------------------------------------*/
WORD HAL_Timer_wGetTimer0Ticks(void)
{
	return Timer0_Ticks;
}


/*----------------------------------------------------------------------
* Function name:		HAL_Timer_ResetTimer0Ticks
* Input:				void
* Output:				void
* Purpose:				reset timer 0 ticks counter
*-----------------------------------------------------------------------*/
void HAL_Timer_ResetTimer0Ticks()
{
	Timer0_Ticks=0;
}

/*----------------------------------------------------------------------
* Function name:		HAL_Timer_wGetActivityCounter
* Input:				void
* Output:				Activity counter value
* Purpose:				get actibity counter value
*-----------------------------------------------------------------------*/
WORD HAL_Timer_wGetActivityCounter(void)
{
	return Timer0_Activity_Counter;
}

/*----------------------------------------------------------------------
* Function name:		HAL_Timer_ResetActivityCounter
* Input:				void
* Output:				void
* Purpose:				reset activity counter value
*-----------------------------------------------------------------------*/
void HAL_Timer_ResetActivityCounter(void)
{
	Timer0_Activity_Counter = 0;
}
