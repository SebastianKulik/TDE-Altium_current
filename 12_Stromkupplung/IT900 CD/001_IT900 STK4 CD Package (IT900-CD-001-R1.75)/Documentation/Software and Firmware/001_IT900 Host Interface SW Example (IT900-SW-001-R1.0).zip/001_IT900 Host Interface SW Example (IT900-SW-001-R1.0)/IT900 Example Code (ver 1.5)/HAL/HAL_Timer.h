#include <HAL_Portability.h>
#include <HAL_Init.h>
#include <io.h>
#include <avr/interrupt.h>



#if !defined(TIMER_123829013478_)
#define TIMER_123829013478_

extern volatile WORD Timer0_Ticks; 

#define HAL_TIMER_MAX_VALUE		  65535

//Timer defines:

#define HAL_TIMER_NO_CLOCK				0x00 
#define HAL_TIMER_CLOCK_DIV_1		   	0x01
#define HAL_TIMER_CLOCK_DIV_8			0x02
#define HAL_TIMER_CLOCK_DIV_32			0x03
#define HAL_TIMER_CLOCK_DIV_64			0x04
#define HAL_TIMER_CLOCK_DIV_128			0x05
#define HAL_TIMER_CLOCK_DIV_256			0x06
#define HAL_TIMER_CLOCK_DIV_1024		0x07  	 		

// Prototypes

extern void HAL_Timer_InitTimer0(void);
extern void HAL_Timer_StartTimer0(BYTE startValue,BYTE prescaling);
extern void HAL_Timer_StopTimer0(void);
extern WORD HAL_Timer_wGetTimer0Ticks (void);
extern void HAL_Timer_ResetTimer0Ticks(void);
extern WORD HAL_Timer_wGetActivityCounter(void);
extern void HAL_Timer_ResetActivityCounter(void);


#endif

