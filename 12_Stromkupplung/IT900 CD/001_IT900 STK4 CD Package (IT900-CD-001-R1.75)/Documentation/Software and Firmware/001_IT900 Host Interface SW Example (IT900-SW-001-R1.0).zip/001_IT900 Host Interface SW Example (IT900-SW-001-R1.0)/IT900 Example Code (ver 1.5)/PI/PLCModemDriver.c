#define PLCModem_DRIVER_H_MAIN_FILE
#include <PLCModemDriver.h>


// NOP reset command
BYTE sbyNOPCmdDY[] =
{
	HOST_EI_ATTENTION,
	02,
	00,
	eHOST_EI_PACKET_TYPES_REQUEST,
	(eHOST_EI_SERVICE_TYPES_EMBEDDED_SERVICES  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
		+ eHOST_EI_SERVICE_SUBTYPES_EMBEDDED_SERVICES_NO_OP
};

// Software reset command
BYTE sbyResetCmdDY[] =
{
	HOST_EI_ATTENTION,
	02,
	00,
	eHOST_EI_PACKET_TYPES_REQUEST,
	(eHOST_EI_SERVICE_TYPES_STACK_SERVICES  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
		+ eHOST_EI_SERVICE_SUBTYPES_STACK_SERVICES_RESET,
	0x22 //checksum. This command sent directly (not through s_bSendWaitForResponse)
};


// Go online command
BYTE sbyGoOnlineCmdDY[] =
{
	HOST_EI_ATTENTION,
	02,
	00,
	eHOST_EI_PACKET_TYPES_REQUEST,
	(eHOST_EI_SERVICE_TYPES_STACK_SERVICES  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
		+ eHOST_EI_SERVICE_SUBTYPES_STACK_SERVICES_GO_ONLINE
};


/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_ClearIncomingRspPacket
* Input:				void
* Output:				void
* Purpose:				Incoming Response Parsed - Ready to receive
						the new one
*-----------------------------------------------------------------------*/
static void s_ClearIncomingRspPacket(void)
{
	g_PLCModemDriver_struct.strInResp.bInRespRxFlag = FALSE;
	g_PLCModemDriver_struct.byIncomingPacketOpcode = 0;
	g_PLCModemDriver_struct.byIncomingPacketType = 0;
}

/*----------------------------------------------------------------------
* Function name:		s_byCalcCheckSum
* Input:				pointer to data, data length
* Output:				checksum value
* Purpose:				calaultion of checksum for host command
*-----------------------------------------------------------------------*/
static BYTE s_byCalcCheckSum(PBYTE pbyData, WORD wLength)
{
	BYTE byResp = 0;
	WORD i;
	for (i=0;i<wLength;i++)
	{
		byResp += pbyData[i];
	}

	return byResp;
}

/*----------------------------------------------------------------------
* Function name:	bSend_WaitForResponse
* Input:					pointer to data, data length
* Output:					timeout
* Purpose:				transmit packet and wait for response
*-----------------------------------------------------------------------*/
static BOOL s_bSendWaitForResponse(PBYTE pbyData, WORD wLength)
{
	WORD wTimeoutTicks;
	BYTE byCheckSum;


	s_ClearIncomingRspPacket();

	byCheckSum = s_byCalcCheckSum(&pbyData[eHOST_EI_IDX_LENGTH_LSB], wLength - eHOST_EI_IDX_LENGTH_LSB);


	// transmit command via UART
	HAL_UART_UART1_Transmit(pbyData, wLength);
	HAL_UART_UART1_Transmit(&byCheckSum, 1); // transmit checksum
	// calculate timeout ticks:
	wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(PLCModem_DRIVER_TIMEOUT_TICKS);
	// wait while response received, and right command ID available
	// note: when using OS, "while statement" can be replaced with "wait for event" operation
	while(
		 (!g_PLCModemDriver_struct.strInResp.bInRespRxFlag) ||
			 (g_PLCModemDriver_struct.byIncomingPacketOpcode != pbyData[eHOST_EI_IDX_OPCODE])
		  )
	{
	  if(PLCModemDriver_bIsTimeoutOccured(wTimeoutTicks))
	  {
		return FALSE; // return FALSE if timeout
	  }
	}
	return TRUE;
}

/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_Reset_PIM_HW
* Input:				void
* Output:				Status
* Purpose:				Hard Reset PLCModem and wait for Reset response
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bReset_PIM_HW(void)
{
 	WORD i;
	WORD wTimeoutTicks;
	BOOL bSuccess = TRUE;
	g_PLCModemDriver_struct.bResetReceived = FALSE;
	s_ClearIncomingRspPacket();
	HAL_IO_togglePin		  		// Clear RESET pin
	(
		PIM_RESET_PORT,
		PIM_RESET_PIN,
		OUT,
		CLEAR
	);

	for(i=0;i<0xFFFF;i++); 			// delay of 336ms
				
	HAL_IO_togglePin				// Set RESET pin
	(
		PIM_RESET_PORT,
		PIM_RESET_PIN,
		OUT,
		SET
	);
// calculate timer timeout value
	wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(PLCModem_DRIVER_TIMEOUT_TICKS);
	while(!g_PLCModemDriver_struct.bResetReceived) // wait for Reset response to
	{											// be received from PLCModem
	  if(PLCModemDriver_bIsTimeoutOccured(wTimeoutTicks))
	  {
	    bSuccess = FALSE; 	 			   		// exit if timeout occurred
		  break;
	  }
	}

	if(
		((g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_SUCCESS) ||			// check if response is valid
		(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_AUTOCONFIG) ||
	    (g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_LOADDEFAULT)) && bSuccess
     )
	{
	   g_PLCModemDriver_struct.bResetReceived = FALSE; // reset received flag
	}
	else
	{
	  bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_Reset_PIM_HW
* Input:			void
* Output:			Status
* Purpose:			Soft Reset PLCModem and wait for Reset response
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bReset_PIM_SW(void)
{
	BOOL bSuccess = TRUE;
	WORD wTimeoutTicks;
	g_PLCModemDriver_struct.bResetReceived = FALSE;
	s_ClearIncomingRspPacket();
	HAL_UART_UART1_Transmit(sbyResetCmdDY, sizeof(sbyResetCmdDY)); // transmit reset command
	wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(PLCModem_DRIVER_TIMEOUT_TICKS);
	while(!g_PLCModemDriver_struct.bResetReceived) // wait for response
	{
	  if(PLCModemDriver_bIsTimeoutOccured(wTimeoutTicks))
	  {
	    bSuccess = FALSE;
		  break;
	  }
	}

	// check if response is valid
	if(
		((g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_SUCCESS) ||			// check if response is valid
		(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_AUTOCONFIG) ||
	    (g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] ==
		     HOST_EI_RESET_CAUSE_LOADDEFAULT)) && bSuccess
     )
	{
	   g_PLCModemDriver_struct.bResetReceived = FALSE;
	}
	else
	{
	  bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_Init
* Input:			void
* Output:			void
* Purpose:			Init Driver:
					Init PLCModemDriver variables
					Set UART CB Rx Function
					Start Timeout Timer
*-----------------------------------------------------------------------*/
void PLCModemDriver_Init(void)
{
	g_PLCModemDriver_struct.byIncomingPacketOpcode = 0;
	g_PLCModemDriver_struct.byIncomingPacketType = 0;
	g_PLCModemDriver_struct.pOnIncomingDataPacket = NULL;
	g_PLCModemDriver_struct.wInLength = 0;
	g_PLCModemDriver_struct.wInPLIdx = 0;

	g_PLCModemDriver_struct.strInData.bInDataRxFlag = FALSE;
	g_PLCModemDriver_struct.strInData.wIncomingDataPacketLength = 0;

	g_PLCModemDriver_struct.strInResp.bInRespRxFlag = FALSE;

	g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;

	// set pointer to incoming data CB function:
//	HAL_UART_UART1_SetOnRxByteCB(PLCModemDriver_CB_OnRxByte);

	// start timer
	HAL_Timer_StartTimer0(0x00,HAL_TIMER_CLOCK_DIV_1024);
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_CB_OnRxByte
* Input:			incoming byte
* Output:			void
* Purpose:			process incoming data. Save incoming data to
					1 of 3 buffers according to the packet ID:
					1. Response Buffer
					2. Rx Data Packet Buffer
					3. NL Buffer
*-----------------------------------------------------------------------*/
void PLCModemDriver_CB_OnRxByte(BYTE byData)
{

	switch(g_PLCModemDriver_struct.byRxState) // check the RX state
	{
		// state: no data available
		case (ePLCModemDRIVER_RX_STATES_ATTN):
			// check if attention char received
			if(byData == HOST_EI_ATTENTION)
			{
				g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_LENGTH_L;
				g_PLCModemDriver_struct.byCheckSum = 0;
			}
			break;

		// state: wait for length LSB
		case (ePLCModemDRIVER_RX_STATES_LENGTH_L):
			// store length LSB
			g_PLCModemDriver_struct.wInLength = byData;
			// move to 'wait for length MSB'
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_LENGTH_H;
			g_PLCModemDriver_struct.byCheckSum += byData;
			break;

		// state: wait for MSB
		case (ePLCModemDRIVER_RX_STATES_LENGTH_H):
			// Store length MSB
			g_PLCModemDriver_struct.wInLength += ((WORD)byData << 8);
			// move to 'wait for PAYLOAD'
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_TYPE;
			// Clear Incoming Data Index
			g_PLCModemDriver_struct.wInPLIdx = 0;
			g_PLCModemDriver_struct.byCheckSum += byData;
			break;
		// state: wait for TYPE
		case (ePLCModemDRIVER_RX_STATES_TYPE):
			g_PLCModemDriver_struct.wInPLIdx++;
			// store incoming packet's type
			g_PLCModemDriver_struct.byIncomingPacketType = byData;
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_OPCODE;
			g_PLCModemDriver_struct.byCheckSum += byData;
			break;
		// state: wait for OPCODE
		case (ePLCModemDRIVER_RX_STATES_OPCODE):
			g_PLCModemDriver_struct.wInPLIdx++;
			// store incoming packets's opcode
			g_PLCModemDriver_struct.byIncomingPacketOpcode = byData;
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_PAYLOAD;
			g_PLCModemDriver_struct.byCheckSum += byData;
			break;
		// state: wait for PAYLOAD
		case (ePLCModemDRIVER_RX_STATES_PAYLOAD):
			g_PLCModemDriver_struct.byCheckSum += byData;
			if(g_PLCModemDriver_struct.wInLength > g_PLCModemDriver_struct.wInPLIdx)
			{
				switch(g_PLCModemDriver_struct.byIncomingPacketType)
				{
					case (eHOST_EI_PACKET_TYPES_RESPONSE):
						// Fill Response Buffer
						PLCModemDriver_FillRspBuffer(byData);
						break;
						// Fill Rx Data Buffer
					case (eHOST_EI_PACKET_TYPES_INDICATION):
						if ((g_PLCModemDriver_struct.byIncomingPacketOpcode >> HOST_EI_OPCODE_SERVICE_TYPE_SHIFT) ==
							eHOST_EI_SERVICE_TYPES_MANAGMENT_SA)
						{
							// Fill network layer indications buffer
							PLCModemDriver_FillNLBuffer(byData);
						}
						else
						{
							// Fill Data indications buffer
							PLCModemDriver_FillRxDataBuffer(byData);
						}
						break;
					default:
						g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;
				}
			}
			else
			{
				g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;
			}
			break;
		case (ePLCModemDRIVER_RX_STATES_CHECKSUM):
			if(g_PLCModemDriver_struct.byCheckSum != byData)
			{
				// wrong checksum - go to attention state
				g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;
				break;
			}

			if(((g_PLCModemDriver_struct.byIncomingPacketOpcode & HOST_EI_OPCODE_SERVICE_SUB_TYPE_MASK) ==
				eHOST_EI_SERVICE_SUBTYPES_STACK_SERVICES_RESET ) &&
				((g_PLCModemDriver_struct.byIncomingPacketOpcode >> HOST_EI_OPCODE_SERVICE_TYPE_SHIFT) ==
				eHOST_EI_SERVICE_TYPES_STACK_SERVICES ))
			{
				g_PLCModemDriver_struct.bResetReceived = TRUE;
			}

			switch(g_PLCModemDriver_struct.byIncomingPacketType)
			{
				case (eHOST_EI_PACKET_TYPES_RESPONSE):
					// Command response received - set Resp RX flag
					g_PLCModemDriver_struct.strInResp.bInRespRxFlag = TRUE;
					break;
					// Fill Rx Data Buffer
				case (eHOST_EI_PACKET_TYPES_INDICATION):
					if ((g_PLCModemDriver_struct.byIncomingPacketOpcode >> HOST_EI_OPCODE_SERVICE_TYPE_SHIFT) ==
						eHOST_EI_SERVICE_TYPES_MANAGMENT_SA)
					{
						// NL indication received - call NL management handler
						NLMngHandler_MessageHandler
						(
							g_PLCModemDriver_struct.pbyInNLBuffer,
							g_PLCModemDriver_struct.wInLength - 2,
							g_PLCModemDriver_struct.byIncomingPacketOpcode & HOST_EI_OPCODE_SERVICE_SUB_TYPE_MASK
						);
					}
					else
					{
						// Data Packet Received - Set RX Flag
						g_PLCModemDriver_struct.strInData.wIncomingDataPacketLength =
							g_PLCModemDriver_struct.wInLength;
						g_PLCModemDriver_struct.strInData.bInDataRxFlag = TRUE;
					}
					break;
				default:
					g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;
			}
		default:
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_ATTN;

	}
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bGoOnline
* Input:			void
* Output:			Status
* Purpose:			send go online command
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bGoOnline(void)
{
  BOOL bSuccess = TRUE;
  // send 'go online' command
  if(s_bSendWaitForResponse(sbyGoOnlineCmdDY, sizeof(sbyGoOnlineCmdDY)))
  {
    if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != PLCModem_DRIVER_COMMAND_EXECUTED)
    {
      bSuccess = FALSE; // fail if response is FALSE
    }
  }
  else
  {
    bSuccess = FALSE;
  }

  // Incoming Packet Parsed - Release the Buffer
  s_ClearIncomingRspPacket();
  return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bGetParam
* Input:			Pointer to parameter, index, table type
* Output:			Status
* Purpose:			Get a single Modem Parameter
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bGetParam(PWORD pwParameter, WORD wIndex, BYTE byTable)
{
	BOOL bSuccess = TRUE;
	// prepare outgoing command buffer
	BYTE sbyCommand[eHOST_EI_CMD_GET_PARAMETERS_LENGTH + eHOST_EI_IDX_DATA];
	// prepare command header
	PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_GET_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_GET_PARAMETERS_LENGTH,
		sbyCommand
	);
	// set table index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_TABLE] = byTable;

	// set parameter index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_INDEX_L] =
		(BYTE)(wIndex & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_INDEX_H] =
		(BYTE)(wIndex >> 8);

	// only one parameter can be read - set parameters count to 1
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_NUM_L] = 1;
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_NUM_H] = 0;

	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		// copy requested parameter
		*pwParameter =
		  (WORD)g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[HOST_EI_CMD_GET_PARAMETER_RSP_DATA_IDX] +
		  (WORD)g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[HOST_EI_CMD_GET_PARAMETER_RSP_DATA_IDX + 1] * 256;
	}
	else
	{
		bSuccess = FALSE; // return false if timeout occurred
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}




/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bSetParam
* Input:			parameter, index, table
* Output:			Status
* Purpose:			Set a single Modem Parameter / Set factory default
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSetParam(WORD wParameter, WORD wIndex, BYTE byTable)
{
	BOOL bSuccess = TRUE;
	// prepare outgoing packet buffer
	BYTE sbyCommand[eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH + eHOST_EI_IDX_DATA];

	//prepare packet header
	PLCModemDriver_PrepareHeader
	(
	  (eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_SET_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH,
		sbyCommand
	);

  // set table index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_TABLE] = byTable;

	// set parameter index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_L] =
		(BYTE)(wIndex & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_H] =
		(BYTE)(wIndex >> 8);

	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_L] =
		(BYTE)(wParameter & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_H] =
		(BYTE)(wParameter >> 8);

	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
		{
			bSuccess = FALSE; // return false if FALSE answer received
		}
	}
	else
	{
		bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bGetSerialNum
* Input:			Pointer to parameter
* Output:			Status
* Purpose:			Get the Modem Serial Number
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bGetSerialNum(PBYTE pbySN)
{
	const BYTE byTable = HOST_EI_PARAMETER_TABLES_SERIAL_NUMBER;
	const WORD wIndex  = HOST_EI_CMD_SET_PARAMETERS_SN_IDX;
	int i;

	BOOL bSuccess = TRUE;
	// prepare outgoing command buffer
	BYTE sbyCommand[eHOST_EI_CMD_GET_PARAMETERS_LENGTH + eHOST_EI_IDX_DATA];
	// prepare command header
	PLCModemDriver_PrepareHeader
		(
		(eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
		+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_GET_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_GET_PARAMETERS_LENGTH,
		sbyCommand
		);
	// set table index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_TABLE] = byTable;
	
	// set parameter index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_INDEX_L] =
		(BYTE)(wIndex & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_INDEX_H] =
		(BYTE)(wIndex >> 8);
	
	// only one parameter can be read - set parameters count to 1
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_NUM_L] = 1;
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_PARAMETERS_IDX_NUM_H] = 0;
	
	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		// copy requested parameter
		for(i=0;i<PLCModem_DRIVER_SN_LENGTH;i++)
		{
			pbySN[i] = (BYTE)g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[HOST_EI_CMD_GET_PARAMETER_RSP_DATA_IDX+i];
		}
		
	}
	else
	{
		bSuccess = FALSE; // return false if timeout occurred
	}
	
	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bSetSerialNum
* Input:			pointer to serial number buffer
* Output:			Status
* Purpose:			Set my serial number (set parameter with table ID 0x05)
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSetSerialNum(PBYTE pbySN)
{
	BOOL bSuccess = TRUE;
	// prepare outgoing packet buffer
	BYTE sbyCommand[eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_L + PLCModem_DRIVER_SN_LENGTH + eHOST_EI_IDX_DATA];

	//prepare packet header
	PLCModemDriver_PrepareHeader
	(
	  (eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_SET_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_L + PLCModem_DRIVER_SN_LENGTH,
		sbyCommand
	);

    // set table index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_TABLE] =	HOST_EI_PARAMETER_TABLES_SERIAL_NUMBER;

	// set command special validity code:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_L] = 0xAB;
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_H] = 0xBA;


	memcpy
	(
		&sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_L],
		pbySN,
		PLCModem_DRIVER_SN_LENGTH
	);


	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
		{
			bSuccess = FALSE; // return false if FALSE answer received
		}
	}
	else
	{
		bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:			PLCModemDriver_bSetPredefined
* Input:					band index
* Output:					Status
* Purpose:					Set Modem Predefined Parameters (DLL,NL)
  								byBand can be:
									1. 0 - FCC
									2. 1 - ARIB
									3. 2 - CA
									4. 3 - CA2/CB
									5. 4 - CA3
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSetPredefined(BYTE byBand)
{
	BOOL bSuccess = TRUE;
	// prepare outgoing packet buffer
	BYTE sbyCommand[eHOST_EI_CMD_SET_PREDEFINED_PARAMETERS_LENGTH + eHOST_EI_IDX_DATA];


	//prepare packet header
	PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_SET_PREDEFINED,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_SET_PREDEFINED_PARAMETERS_LENGTH,
		sbyCommand
	);

	// set parameters table:
	sbyCommand[eHOST_EI_CMD_SET_PREDEFINED_PARAMETERS_IDX_TABLE + eHOST_EI_IDX_DATA] = 0xFF; // constant- all parameters
	sbyCommand[eHOST_EI_CMD_SET_PREDEFINED_PARAMETERS_IDX_REGION + eHOST_EI_IDX_DATA] = byBand;


	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
		{
			bSuccess = FALSE; // return false if FALSE answer received
		}

	}
	else
	{
		bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_PrepareHeader
* Input:			Cmd ID, packet length, pointer to packet
* Output:			void
* Purpose:			prepare packet's header
*-----------------------------------------------------------------------*/
void PLCModemDriver_PrepareHeader(BYTE byCmd, WORD wLength, PBYTE pbyBuffer)
{
	// set header values:
	pbyBuffer[eHOST_EI_IDX_ATTENTION] = HOST_EI_ATTENTION;
	pbyBuffer[eHOST_EI_IDX_TYPE] = eHOST_EI_PACKET_TYPES_REQUEST;
	pbyBuffer[eHOST_EI_IDX_OPCODE] = byCmd;
	pbyBuffer[eHOST_EI_IDX_LENGTH_LSB] = (BYTE)(wLength & 0xff);
	pbyBuffer[eHOST_EI_IDX_LENGTH_MSB] = (BYTE)(wLength >> 8);
}


/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_bSaveParameters
* Input:				void
* Output:				status
* Purpose:				send save parameters command
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSaveParameters(void)
{
	BOOL bSuccess = TRUE;
	// prepare command buffer:
	BYTE sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SAVE_PARAMETERS_LENGTH];

	// prepare command header
	PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_SAVE_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_SAVE_PARAMETERS_LENGTH,
		sbyCommand
	);

	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SAVE_PARAMETERS_IDX_TABLE] = 0xFF; // constant

	if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
	{
		if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
		{
			bSuccess = FALSE; // return FALSE if CMD RES is FALSE
		}
	}
	else
	{
		bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_TransmitPacket
* Input:			pointer to data, data length,
  					target node ID,
					priority(low/normal/high),
					service(ACK/UNACK),
					hops(0-16)
					gain(0-7)
					target port(0-15)
* Output:			status
* Purpose:			transmit packet V2 packet via PLC. This function
					transmits packet to DLL, waits for first response
					(Accepted/Rejected), then it waits for second response
					(Repeated, Ack/NoAck). FALSE is returned if packet
					wasn't transmitted for some reason (timeout, not
					accepted)
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_TransmitPacket
(
  PBYTE pbyData,
  WORD wLength,
  WORD wNodeID,
  BYTE byPriority,
  BYTE byService,
  BYTE byHops,
  BYTE byGain,
  BYTE byPort
)
{
	WORD wTimeoutTicks;
	// prepare output buffer - max size:
	BYTE sbyOutBuffer[PLCModem_DRIVER_OUT_BUFFER_LENGTH];
	BYTE byCmdHeaderLength =
	  (wNodeID ? HOST_EI_CMD_TX_PACKET_HEADER_LEN_WITH_SHORT: HOST_EI_CMD_TX_PACKET_HEADER_LEN_BRDCAST);
	BOOL bSuccess = TRUE;
	// prepare packet header
	PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_NL_DATA  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_NL_DATA_TX_PACKET,
		PLCModem_DRIVER_LENGTH_ADDON + byCmdHeaderLength + wLength,
		sbyOutBuffer
	);
	// set Tx packet parameters:

	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_TYPE + eHOST_EI_IDX_DATA] =
		(wNodeID ? eHOST_EI_CMD_TX_PACKET_TYPES_INTRANETWORKING_UNICAST_SA :
			eHOST_EI_CMD_TX_PACKET_TYPES_INTRANETWORKING_BROADCAST);
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_PRTY + eHOST_EI_IDX_DATA] =
		byPriority;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_SERV + eHOST_EI_IDX_DATA] =
		byService;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_HOP + eHOST_EI_IDX_DATA] =
		byHops;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_GAIN + eHOST_EI_IDX_DATA] =
		byGain;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_STAGLO + eHOST_EI_IDX_DATA] = 1;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_STAGHI + eHOST_EI_IDX_DATA] = 0;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_ENCRYPTED + eHOST_EI_IDX_DATA] = 0;
	sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_TGT_PORT + eHOST_EI_IDX_DATA] = byPort;

	if(wNodeID)
	{
		sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_DEST_ADDRESS + eHOST_EI_IDX_DATA] =
			(BYTE)(wNodeID & 0xff);
		sbyOutBuffer[eHOST_EI_CMD_TX_PACKET_IDX_DEST_ADDRESS + eHOST_EI_IDX_DATA + 1] =
			(BYTE)(wNodeID >> 8);
	}

	memcpy // copy packet data
	(
	  &sbyOutBuffer[byCmdHeaderLength + eHOST_EI_IDX_DATA],
	  pbyData,
	  wLength
	);
  // transmit packet and wait for first response (accepted/rejected)
  if(s_bSendWaitForResponse(sbyOutBuffer, byCmdHeaderLength + wLength + eHOST_EI_IDX_DATA))
  {
	  if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[eHOST_EI_TX_PACKET_RESP_ACCEPTED_IDX_RSP_RESULT] ==
				eHOST_EI_TX_PACKET_RESP_ACCEPTED_STATUS_ACCEPTED)
	  {
			// if packet accepted - wait for second response
			s_ClearIncomingRspPacket();


//			TODO: uncomment if we want to wait for second response.
//			note: when using OS, "while statement" can be replaced with "wait for event" operation
//
// 		    wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(PLCModem_DRIVER_TIMEOUT_TICKS);
// 			while(
// 					(!g_PLCModemDriver_struct.strInResp.bInRespRxFlag) ||
// 					(g_PLCModemDriver_struct.byIncomingPacketOpcode != sbyOutBuffer[eHOST_EI_IDX_OPCODE])
// 					)
// 			{
// 				if(PLCModemDriver_bIsTimeoutOccured(wTimeoutTicks))
// 				{
// 					bSuccess = FALSE; // timeout
// 					break;
// 				}
// 			}
// 
// 
// 			// check if packet was successfully transmitted
// 			if
// 			(
// 				(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[eHOST_EI_TX_PACKET_RESP_NUM_IDX] ==
// 				eHOST_EI_CMD_TX_PACKET_RESP_NUM_SENT) &&
// 				((g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[eHOST_EI_TX_PACKET_RESP_SENT_IDX_RSP_RESULT] ==
// 				eHOST_EI_TX_PACKET_RESP_SENT_STATUS_OK) || (g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[eHOST_EI_TX_PACKET_RESP_SENT_IDX_RSP_RESULT] ==
// 				eHOST_EI_TX_PACKET_RESP_SENT_STATUS_NO_ACK)) &&
// 					bSuccess
// 			)
// 			{
// 				bSuccess = TRUE;
// 			}
// 			else
// 			{
// 				bSuccess = FALSE;
// 			}


	  }
	  else
	  {
	     bSuccess = FALSE;
	  }

  }
  else
  {
	  bSuccess = FALSE;
  }

  // Incoming Packet Parsed - Release the Buffer
  s_ClearIncomingRspPacket();
  return bSuccess;
}




/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_ManageModem
* Input:			void
* Output:			void
* Purpose:			manage PLCModem driver - called from main loop
  					1. start modem if reset response was received
					2. call on incoming data packet CB - if there is new
					packet pending
*-----------------------------------------------------------------------*/
void PLCModemDriver_ManageModem(void)
{
	if(g_PLCModemDriver_struct.bResetReceived == TRUE)
	{
		g_PLCModemDriver_struct.bResetReceived = FALSE;
		  PLCModemDriver_bGoOnline(); // init modem if reset response received
	}
	if(g_PLCModemDriver_struct.strInData.bInDataRxFlag)
	{
		if (g_PLCModemDriver_struct.strInData.pbyInDataBuffer[eHOST_EI_RX_PACKET_INTRANET_IDX_SHORT_PORT -
															eHOST_EI_IDX_DATA] == HOST_EI_REMOTE_CONFIG_PORT)
		{
			// handle remote configuration response
		}
		// check if indication of remote configuration change has received
		else if (((g_PLCModemDriver_struct.byIncomingPacketOpcode & HOST_EI_OPCODE_SERVICE_SUB_TYPE_MASK) ==
				eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_REMOTE_PARAMETERS_CHANGE ) &&
				((g_PLCModemDriver_struct.byIncomingPacketOpcode >> HOST_EI_OPCODE_SERVICE_TYPE_SHIFT) ==
				eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR ))
		{
			// handle remote configuration change indication
		}
		else
		{
			if(g_PLCModemDriver_struct.pOnIncomingDataPacket != NULL)
			{
				g_PLCModemDriver_struct.pOnIncomingDataPacket // call OnIncomingPacket CB
				  (
					   &g_PLCModemDriver_struct.strInData.pbyInDataBuffer[eHOST_EI_RX_PACKET_INTRANET_IDX_SHORT_DATA - eHOST_EI_IDX_DATA],
					   g_PLCModemDriver_struct.strInData.wIncomingDataPacketLength + 3 - eHOST_EI_RX_PACKET_INTRANET_IDX_SHORT_DATA,
					   g_PLCModemDriver_struct.strInData.pbyInDataBuffer[eHOST_EI_RX_PACKET_INTRANET_IDX_SHORT_ORIGIN_ID_LO - eHOST_EI_IDX_DATA] +
							g_PLCModemDriver_struct.strInData.pbyInDataBuffer[eHOST_EI_RX_PACKET_INTRANET_IDX_SHORT_ORIGIN_ID_HI - eHOST_EI_IDX_DATA] * 256
					);
			}
		}
		g_PLCModemDriver_struct.strInData.bInDataRxFlag = FALSE;
	}
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_SetOnIncomingPacketPointer
* Input:			Pointer to on incoming CB function
* Output:			void
* Purpose:			set on incoming CB function pointer
  					prototype:
  					void pfn(PBYTE pbyData, WORD wLength, WORD wSrcID)
*-----------------------------------------------------------------------*/
void PLCModemDriver_SetOnIncomingPacketPointerCB(pfOnIncomingPacketCBDY pfn)
{
  g_PLCModemDriver_struct.pOnIncomingDataPacket = pfn;
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_wCalculateTimeoutValue
* Input:			requested number of ticks
* Output:			timer value after requesed number of ticks
* Purpose:			calculate timer value
*-----------------------------------------------------------------------*/
WORD PLCModemDriver_wCalculateTimeoutValue(WORD wTicks)
{
	WORD wCurrentTicks;
	HAL_Timer_ResetTimer0Ticks();
	wCurrentTicks = (WORD)HAL_Timer_wGetTimer0Ticks();
	if((HAL_TIMER_MAX_VALUE - wCurrentTicks) > wTicks)
	{
		// no overflow will occur
		return(wCurrentTicks + wTicks);
	}
	else
	{
		// overflow will occur
		return(wTicks - (HAL_TIMER_MAX_VALUE - wCurrentTicks));
	}
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bIsTimeoutOccured
* Input:			timer timeout ticks
* Output:			timeout occured/not occured
* Purpose:			Check if Timer Timeout Occured
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bIsTimeoutOccured(WORD wTimeoutTicks)
{
	WORD wTicks = (WORD)HAL_Timer_wGetTimer0Ticks();
	if(wTicks >= wTimeoutTicks)
	{
	  return TRUE;
	}
	else
	{
	  return FALSE;
	}
}

/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_FillRspBuffer
* Input:				Incoming Data Byte
* Output:				None
* Purpose:				Save incoming data to Response Buffer. If the
						whole packet received, set bInRespRxFlag flag
*-----------------------------------------------------------------------*/
void PLCModemDriver_FillRspBuffer(BYTE byData)
{
	if(!g_PLCModemDriver_struct.strInResp.bInRespRxFlag)
	{
		// Save data Byte into Incoming Response Buffer
		g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
			[
				g_PLCModemDriver_struct.wInPLIdx - 2
			] = byData;

		g_PLCModemDriver_struct.wInPLIdx++;

		if(g_PLCModemDriver_struct.wInPLIdx == g_PLCModemDriver_struct.wInLength)
		{
			// Set Receiver State to ATTN
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_CHECKSUM;
			// Check if there is incoming Reset Packet

		}
	}
}

/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_FillRxDataBuffer
* Input:				Incoming Data Byte
* Output:				None
* Purpose:				Save incoming data to Rx Data Buffer. If the
						whole Data Packet received set bInDataRxFlag flag.
						Data packet will be parsed from
						PLCModemDriver_ManageModem function.
*-----------------------------------------------------------------------*/
void PLCModemDriver_FillRxDataBuffer(BYTE byData)
{
	if (!g_PLCModemDriver_struct.strInData.bInDataRxFlag)
	{
		// Save data Byte into incoming Rx Data buffer
		g_PLCModemDriver_struct.strInData.pbyInDataBuffer
			[
				g_PLCModemDriver_struct.wInPLIdx - 2
			] = byData;

		g_PLCModemDriver_struct.wInPLIdx++;

		if(g_PLCModemDriver_struct.wInPLIdx == g_PLCModemDriver_struct.wInLength)
		{
			// Set Receiver State to ATTN
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_CHECKSUM;
		}
	}
	else
	{
		// ignore incoming data packet if previous one was not processed
		g_PLCModemDriver_struct.wInPLIdx++;
		if(g_PLCModemDriver_struct.wInPLIdx == g_PLCModemDriver_struct.wInLength)
		{
			g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_CHECKSUM;
		}
	}
}

/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_FillNlBuffer
* Input:				Incoming Data Byte
* Output:				None
* Purpose:				Save incoming data to NL Buffer. If the Whole
						packet received, call ARAHandler_MessageHandler
						function. There is no NL Received Flag because
						NL management messages immediately moved to
						NL management Handler
*-----------------------------------------------------------------------*/
void PLCModemDriver_FillNLBuffer(BYTE byData)
{
	g_PLCModemDriver_struct.pbyInNLBuffer[g_PLCModemDriver_struct.wInPLIdx - 2] =
		byData;

	g_PLCModemDriver_struct.wInPLIdx++;

	if(g_PLCModemDriver_struct.wInPLIdx == g_PLCModemDriver_struct.wInLength)
	{
		// Set Receiver State to ATTN
		g_PLCModemDriver_struct.byRxState = ePLCModemDRIVER_RX_STATES_CHECKSUM;
	}
}

/*----------------------------------------------------------------------
* Function name:		PLCModemDriver_bSendAdmissionResponse
* Input:				Response parameter (0x0000 - admit, 0x2000 - refuse)
* Output:				None
* Purpose:				Prepare admission response packet and transmit
						to modem. The packet includes admission response
						field(WORD) as first 2 bytes and original
						admission request message
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSendAdmissionResponse
(
	WORD wResponse,
	PBYTE pbyOrigData,
	WORD wOrigLength
)
{
	// prepare output buffer - max size:
	BOOL bSuccess;
	BYTE sbyOutBuffer[PLCModem_DRIVER_OUT_BUFFER_LENGTH];
	PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_MANAGMENT_SA  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_MANAGMENT_SA_NODE_ADMISSION_RSP,
		PLCModem_DRIVER_LENGTH_ADDON + wOrigLength + sizeof(WORD), // + Admission Response
		sbyOutBuffer
	);

	memcpy(&sbyOutBuffer[eHOST_EI_IDX_DATA + sizeof(WORD)], pbyOrigData, wOrigLength);
	sbyOutBuffer[eHOST_EI_IDX_DATA] = (BYTE)(wResponse & 0xff);
	sbyOutBuffer[eHOST_EI_IDX_DATA + 1] = (BYTE)(wResponse >> 8);

	if(s_bSendWaitForResponse(sbyOutBuffer, wOrigLength + sizeof(WORD) + eHOST_EI_IDX_DATA))
	{
		if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
		{
			bSuccess = FALSE; // return FALSE if CMD RES is FALSE
		}
	}
	else
	{
		bSuccess = FALSE;
	}

	// Incoming Packet Parsed - Release the Buffer
	s_ClearIncomingRspPacket();
	return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bGetNcDatabaseSize
* Input:			pointer to max size, pointer to current size
* Output:			Status
* Purpose:			Get NC Database sizes (current and max)
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bGetNcDatabaseSize(PWORD pwMaxSize, PWORD pwCurrSize)
{
  BOOL bSuccess = TRUE;
  // prepare outgoing packet buffer:
  BYTE sbyCommand[eHOST_EI_IDX_DATA + HOST_EI_CMD_GET_NC_DATABASE_SIZE_LENGTH];

  sbyCommand[eHOST_EI_IDX_DATA + HOST_EI_CMD_GET_NC_DATABASE_SIZE_FLAG] = TRUE; // constant

  // prepare packet header
  PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_NL_DATA<< HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_NL_DATA_GET_NC_DATABASE_SIZE,
		PLCModem_DRIVER_LENGTH_ADDON + HOST_EI_CMD_GET_NC_DATABASE_SIZE_LENGTH,
		sbyCommand
	);

  if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
  {
    if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] == TRUE)
	  {
	    // response = TRUE
	    // save Maximal NC database table size
	    *pwMaxSize =
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NC_DATABASE_SIZE_RSP_IDX_MAXSIZELO
		    ];
	    *pwMaxSize +=
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NC_DATABASE_SIZE_RSP_IDX_MAXSIZEHI
		    ] * 256;

	    // save current NC database table size
	    *pwCurrSize =
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NC_DATABASE_SIZE_RSP_IDX_CURSIZELO
		    ];
	    *pwCurrSize +=
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NC_DATABASE_SIZE_RSP_IDX_CURSIZEHI
		    ] * 256;
	  }
	  else
	  {
	    bSuccess = FALSE;
	  }
  }
  else
  {
    bSuccess = FALSE;
  }

  // Incoming Packet Parsed - Release the Buffer
  s_ClearIncomingRspPacket();
  return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bGetNodeInfo
* Input:			pointer to StationID, pointer to ParentID, poinet to serial number
  					pointer to Connectivity status, entry index
* Output:			Status
* Purpose:			Get node information from NC Database
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bGetNodeInfo
(
  PWORD pwStationID,
  PWORD pwParentID,
  PBYTE pbySerialNumber,
  PBYTE pbyConnectivityStatus,
  WORD wIndex
)
{
  BYTE i;
  BOOL bSuccess = TRUE;
  // prepare outgoing packet buffer:
  BYTE sbyCommand[eHOST_EI_CMD_GET_NODE_INFO_BY_IDX_LENGTH + eHOST_EI_IDX_DATA];

  // prepare packet header:
  PLCModemDriver_PrepareHeader
	(
		(eHOST_EI_SERVICE_TYPES_NL_DATA<< HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_NL_DATA_READ_NODE_INFO,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_GET_NODE_INFO_BY_IDX_LENGTH,
		sbyCommand
	);
  // set Query key type to 'by index'
  sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_NODE_INFO_QUERY_KEY_TYPE] =
    eHOST_EI_CMD_GET_NODE_INFO_KEY_TYPE_IDX;

  // set NC Database entry index
  sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_NODE_INFO_IDX_ENTRY_L] =
    (BYTE)(wIndex & 0xff);
  sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_GET_NODE_INFO_IDX_ENTRY_H] =
    (BYTE)(wIndex >> 8);

  if(s_bSendWaitForResponse(sbyCommand, sizeof(sbyCommand)))
  {
    if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] == TRUE)
	{
	    // response - true

	    // save Station ID
	    *pwStationID =
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_STATIONIDLO
		    ];
	    *pwStationID +=
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_STATIONIDHI
		    ] * 256;

	    // Save Parent Station ID
	    *pwParentID =
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_PARENTIDLO
		    ];

	    *pwParentID +=
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_PARENTIDHI
		     ] * 256;


		for (i=0; i<PLCModem_DRIVER_SN_LENGTH; i++)
		{
			pbySerialNumber[i] =
				g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
				[
				  eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_STATION_SN + i
				];
		}

	    *pbyConnectivityStatus =
	      g_PLCModemDriver_struct.strInResp.pbyInRespBuffer
		    [
		      eHOST_EI_CMD_GET_NODE_INFO_RSP_IDX_CONNECTIVITY_STATUS
		    ];

	  }
	  else
	  {
	    bSuccess = FALSE;
	  }
  }
  else
  {
    bSuccess = FALSE;
  }

  // Incoming Packet Parsed - Release the Buffer
  s_ClearIncomingRspPacket();
  return bSuccess;
}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bSetV1Mode
* Input:			Enable V1 mode
* Output:			Status
* Purpose:			Enable/Disable V1 mode over PLC
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bSetV1Mode(BOOL bV1)
{
	WORD wConfig = bV1 ? 1:0;
	WORD wCurrentMode;
	// Get current mode
	BOOL bSuccess =
		PLCModemDriver_bGetParam
			(
				&wCurrentMode,
				NLParDef_eIdx_SendV1Packets,
				HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
			);
	if(bSuccess)
	{
		if(wCurrentMode != wConfig)
		{
			// mode change requested
			bSuccess =
				PLCModemDriver_bSetParam
					(
						wConfig,
						NLParDef_eIdx_SendV1Packets,
						HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
					);

			if (bSuccess)
			{
				bSuccess = PLCModemDriver_bSaveParameters();
				bSuccess = PLCModemDriver_bReset_PIM_SW();   // this parameter requires modem reset
			}
		}
	}

	return bSuccess;
}


/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bRemoteSetParam
* Input:					parameter, index, table type, destination nodeID
* Output:					Status
* Purpose:				Set Modem Parameter remotely.
						This function is not used in the code and
						provided as example only. The response from this
						command can be received in PLCModemDriver_ManageModem
						function.
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bRemoteSetParam
(
	WORD wParameter,
	WORD wIndex,
	BYTE byTable,
	WORD wDestNodeID
)
{
	// prepare outgoing packet buffer
	BYTE sbyCommand[eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH + eHOST_EI_IDX_DATA + 1];

	//prepare packet header
	PLCModemDriver_PrepareHeader
	(
	  (eHOST_EI_SERVICE_TYPES_CONFIG_AND_MONITOR  << HOST_EI_OPCODE_SERVICE_TYPE_SHIFT)
			+ eHOST_EI_SERVICE_SUBTYPES_CONFIG_MONITOR_SET_PARAMETERS,
		PLCModem_DRIVER_LENGTH_ADDON + eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH,
		sbyCommand
	);

  // set table index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_TABLE] = byTable;

	// set parameter index:
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_L] =
		(BYTE)(wIndex & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_INDEX_H] =
		(BYTE)(wIndex >> 8);

	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_L] =
		(BYTE)(wParameter & 0xff);
	sbyCommand[eHOST_EI_IDX_DATA + eHOST_EI_CMD_SET_PARAMETERS_IDX_DATA_H] =
		(BYTE)(wParameter >> 8);

	// prepare checksum
	sbyCommand[eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH + eHOST_EI_IDX_DATA]
		= s_byCalcCheckSum
		(
			&sbyCommand[eHOST_EI_IDX_LENGTH_LSB],
			eHOST_EI_CMD_SET_PARAMETERS_IDX_LENGTH + eHOST_EI_IDX_DATA
				- eHOST_EI_IDX_LENGTH_LSB
		);


	return
		PLCModemDriver_TransmitPacket
		(
			sbyCommand,
			sizeof(sbyCommand),
			wDestNodeID,
			PLCModem_DRIVER_DEFAULT_PRIORITY,
			PLCModem_DRIVER_DEFAULT_SERVICE,
			PLCModem_DRIVER_DEFAULT_HOPS,
			PLCModem_DRIVER_DEFAULT_GAIN,
			HOST_EI_REMOTE_CONFIG_PORT
		);

}

/*----------------------------------------------------------------------
* Function name:	PLCModemDriver_bNOP
* Input:			void
* Output:			Status
* Purpose:			send go NOP command
*-----------------------------------------------------------------------*/
BOOL PLCModemDriver_bNOP(void)
{
  BOOL bSuccess = TRUE;
  // send 'go online' command
  if(s_bSendWaitForResponse(sbyNOPCmdDY, sizeof(sbyNOPCmdDY)))
  {
    if(g_PLCModemDriver_struct.strInResp.pbyInRespBuffer[0] != TRUE)
    {
      bSuccess = FALSE; // fail if response is FALSE
    }
  }
  else
  {
    bSuccess = FALSE;
  }

  // Incoming Packet Parsed - Release the Buffer
  s_ClearIncomingRspPacket();
  return bSuccess;
}



