#include <HAL_Init.h>
#include <HAL_IO.h>
#include <HAL_Timer.h>
#include <HAL_UART.h>
#include <PLCModemDriver.h>
#include <NLMngHandler.h>
#include <UARTHandler.h>

//////////////////////////////////////////////////////////////////////////
// Defines
//////////////////////////////////////////////////////////////////////////

// Firmware version
# define MAJOR 2
# define MINOR 0
# define BUILD 0

// Activity Pin defines
#define ACTIVITY_INT_NUM					6

#define ACTIVITY_TIMEOUT_IN_MSEC			1500

#define ACTIVITY_TIMEOUT_IN_TICKS			(ACTIVITY_TIMEOUT_IN_MSEC / 71)

//Station type
#define REMOTE_METER			0
#define NETWORK_CONCENTRATOR	1

//TODO: define the station type here - uncomment one of the definitions below
#define STATION_TYPE REMOTE_METER
//#define STATION_TYPE NETWORK_CONCENTRATOR

// Periodic operations every POLL_TICKS of Timer
#define POLL_TICKS	   	  140

#define DEFAULT_PORT	  0

#define SN_LENGTH		  16

#define DEFAULT_NETWORK_SIZE	10

// Meter request packets definitions
#define METER_REQUEST	  'R'
#define METER_REQUEST_IDX		0
#define METER_REQUEST_LENGTH	1

//////////////////////////////////////////////////////////////////////////
// Global Variables
//////////////////////////////////////////////////////////////////////////
#if STATION_TYPE == NETWORK_CONCENTRATOR
// Node ID of last polled station - we need it to check if response came
// from the polled node
WORD g_wRequestedNodeID;
const BYTE sbyNcSNs[NLMNG_SN_SIZE] = {0x05,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

#else
	// list of approved stations' SNs (LSB FIRST.
	// this list matches NC list
	const BYTE sbyApprovedRsSNs[NLMNG_SN_LIST_SIZE][NLMNG_SN_SIZE]=
	{
	  {
		0x04,0x54,0x00,0x56,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	  },
	  {
		0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	  }
	};
#endif



//////////////////////////////////////////////////////////////////////////
// Functions
//////////////////////////////////////////////////////////////////////////

/////////////////  Remote Meter functions/////////////////////////////////
#if STATION_TYPE == REMOTE_METER
/*----------------------------------------------------------------------
* Function name:	RS_SendValue
* Input:			remote station Node ID, value
* Output:			void
* Purpose:			send current meter value to the Network Concentrator
*-----------------------------------------------------------------------*/
void RS_SendValue(WORD wNodeID, DWORD dwValue)
{
	BYTE sbyValue[sizeof(DWORD)];
	DWORDToString(sbyValue, dwValue);
	PLCModemDriver_TransmitPacket
	(
		sbyValue,
		sizeof(DWORD),
		wNodeID,
		PLCModem_DRIVER_DEFAULT_PRIORITY,
		PLCModem_DRIVER_DEFAULT_SERVICE,
		PLCModem_DRIVER_DEFAULT_HOPS,
		PLCModem_DRIVER_DEFAULT_GAIN,
		DEFAULT_PORT
	);
}

/*----------------------------------------------------------------------
* Function name:	RS_CB_OnIncomingDataPkt
* Input:			pointer to incoming data packet,
					incoming packet length,
					incoming packet source ID
* Output:			void
* Purpose:			process the incoming data packet - if Meter request
					received - transmit meter value
*-----------------------------------------------------------------------*/
void RS_CB_OnIncomingDataPkt(PBYTE pbyData, WORD wLength, WORD wSrcID)
{
	if (pbyData[METER_REQUEST_IDX] == METER_REQUEST)
	{
		if(NLMngHandler_bIsConnectedToBase())
		{
			RS_SendValue(wSrcID, (DWORD)HAL_Timer_wGetTimer0Ticks());
		}
	}
}

#endif
/////////////////End of Remote Meter functions/////////////////////////


/////////////////Network Concentrator functions////////////////////////
#if STATION_TYPE == NETWORK_CONCENTRATOR
/*----------------------------------------------------------------------
* Function name:	NC_SendNodeRequest
* Input:			remote station Node ID
* Output:			void
* Purpose:			send meter request to remote node
*-----------------------------------------------------------------------*/
void NC_SendNodeRequest(WORD wNodeID)
{
	BYTE byData = METER_REQUEST;
	g_wRequestedNodeID = wNodeID;
	PLCModemDriver_TransmitPacket
	(
		&byData,
		METER_REQUEST_LENGTH,
		wNodeID,
		PLCModem_DRIVER_DEFAULT_PRIORITY,
		PLCModem_DRIVER_DEFAULT_SERVICE,
		PLCModem_DRIVER_DEFAULT_HOPS,
		PLCModem_DRIVER_DEFAULT_GAIN,
		DEFAULT_PORT
	);
}

/*----------------------------------------------------------------------
* Function name:	NC_PollNextMeter
* Input:					void
* Output:					void
* Purpose:				look for next node to poll
*-----------------------------------------------------------------------*/
void NC_PollNextMeter(void)
{
	static BYTE s_byCurrentIndex = 0;
	WORD wCurrentSize,wMaxSize;
	WORD wStationID,wParentID;
	BYTE byConnectivityStatus;
	BYTE sbySN[SN_LENGTH];
	BYTE i;

	memset(sbySN, 0, SN_LENGTH);
	// read current source routing table size
	if(PLCModemDriver_bGetNcDatabaseSize(&wMaxSize,&wCurrentSize))
	{
		if(wCurrentSize) // poll node if nodes available
		{
			if(wCurrentSize <= s_byCurrentIndex) // calculate next table index
			{
			  s_byCurrentIndex = 0;
			}
			// read NC Database entry
			if(PLCModemDriver_bGetNodeInfo(&wStationID,&wParentID,sbySN,&byConnectivityStatus,s_byCurrentIndex++))
			{
				HAL_UART_UART0_ShowText("Status: ");
			//	HAL_UART_UART0_ShowNum(byConnectivityStatus);
				switch(byConnectivityStatus)
				{
					case eHOST_EI_CMD_CONNECTIVITY_STATUS_DISCONNECTED:
					{
						HAL_UART_UART0_ShowText("Disconnected");
						break;
					}
					case eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_GOOD:
					{
						HAL_UART_UART0_ShowText("Connected");
						break;
					}
					case eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_LOW_QUALITY:
					{
						HAL_UART_UART0_ShowText("Connected-low quality");
						break;
					}
					case eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_RANK_AVAILABLE:
					{
						HAL_UART_UART0_ShowText("Connected");
						break;
					}
					default:
					{
						HAL_UART_UART0_ShowText("ERROR!!! ");
						break;
					}
				}

				HAL_UART_UART0_NewLine();

				if( (byConnectivityStatus == eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_GOOD) ||
					(byConnectivityStatus == eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_LOW_QUALITY) ||
					(byConnectivityStatus == eHOST_EI_CMD_CONNECTIVITY_STATUS_CONNECTED_RANK_AVAILABLE)
				  )
				{
					HAL_UART_UART0_ShowText("Station's ID: ");
					HAL_UART_UART0_ShowNum(wStationID);
					HAL_UART_UART0_NewLine();
					HAL_UART_UART0_ShowText("Station's SN: ");

					for (i=0;i<SN_LENGTH;i++)
					{
						HAL_UART_UART0_ShowNumHex(sbySN[SN_LENGTH - i -1]);
						if(i != (SN_LENGTH - 1))
						{
							HAL_UART_UART0_ShowText("-");
						}
					}

					HAL_UART_UART0_NewLine();

					NC_SendNodeRequest(wStationID); // send poll request to station
				}
			}
		}
	}
}

/*----------------------------------------------------------------------
* Function name:	NC_CB_OnIncomingDataPkt
* Input:			pointer to incoming data packet,
					incoming packet length,
					incoming packet soure ID
* Output:			void
* Purpose:			process the incoming data packet - toggle debug led
					when the response from the polled station is received
*-----------------------------------------------------------------------*/
void NC_CB_OnIncomingDataPkt(PBYTE pbyData, WORD wLength, WORD wSrcID)
{
	static BYTE s_byLed = 0;
	if(wSrcID == g_wRequestedNodeID) // check if response came from
	{								 // polled station
		if((s_byLed++) & 0x01)
		{
			HAL_IO_TurnOnRed();
		}
		else
		{
			HAL_IO_TurnOffRed();
		}
	}
}

#endif

/////////////////End of Network Concentrator functions/////////////////


/*----------------------------------------------------------------------------------
* Function name:	bSet_Predefined_Band
* Input:			void
* Output:			TRUE  - if setting the parameter has succeed
					FALSE - over wise
* Purpose:			This function will be called only if wants to set
		            the Band, otherwise it will stay on default.			
*----------------------------------------------------------------------------------*/
BOOL bSet_Predefined_Band (void)
{
	WORD wReadParam;
	BOOL bParameterChanged = FALSE;
	BOOL bSuccess;

	bSuccess =
		PLCModemDriver_bGetParam
		(
			&wReadParam,
			NV_PARAMS_LIST_IDX_BAND,
			HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
		);

	if ( (bSuccess) && (wReadParam != eHOST_EI_CMD_PREDEFINED_BANDS_FCC) )
		bParameterChanged = PLCModemDriver_bSetPredefined(eHOST_EI_CMD_PREDEFINED_BANDS_FCC);

	// note that if couldn't get the Parameter, 
	// it also returns FALSE (but maybe a new Parameter is still needed to be set)
	return bParameterChanged;	
}


/*----------------------------------------------------------------------------------
* Function name:	Set_Admission_Mode
* Input:			void
* Output:			TRUE  - if setting the parameter has succeed
					FALSE - over wise
* Purpose:			This function will be called only if wants to set
		            the admission mode, otherwise it will stay on default (auto).			
*----------------------------------------------------------------------------------*/
BOOL Set_Admission_Mode()
{
	BOOL bSuccess;
	BOOL bParameterChanged = FALSE;
	WORD wReadParam;

	bSuccess =
		PLCModemDriver_bGetParam
			(
				&wReadParam,
				NLMNG_EI_DB_ADMISSION_MODE_IDX,
				HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
			);

	if( (bSuccess) && (wReadParam != NLMNG_EI_DB_ADMISSION_MODE_APP) )
	{
		// admission mode change required
		bParameterChanged =
			PLCModemDriver_bSetParam
			(
				(WORD)NLMNG_EI_DB_ADMISSION_MODE_APP,
				NLMNG_EI_DB_ADMISSION_MODE_IDX,
				HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
			);
	}

	// note that if couldn't get the Parameter, 
	// it also returns FALSE (but maybe a new Parameter is still needed to be set)
	return bParameterChanged;
}


/*-----------------------------------------------------------------------------------
* Function name:	Set_NC_Operation_Mode
* Input:			void
* Output:			TRUE  - if setting the parameter has succeed
					FALSE - over wise
* Purpose:			This function will be called only if wants to set
the operation mode as NC.			
*----------------------------------------------------------------------------------*/
BOOL Set_NC_Operation_Mode(void)
{
	BOOL bSuccess;
	BOOL bParameterChanged = FALSE;
	WORD wReadParam;

	bSuccess =
		PLCModemDriver_bGetParam
		(
			&wReadParam,
			NLMNG_EI_DB_OPERATION_MODE_IDX,
			HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
		);

	if ( (bSuccess) && (wReadParam != NLMNG_EI_DB_OPERATION_MODE_BS) )
	{
		// Set station mode to 'BS'
		// operation mode change requested
		bParameterChanged =
			PLCModemDriver_bSetParam
			(
				(WORD)NLMNG_EI_DB_OPERATION_MODE_BS,
				NLMNG_EI_DB_OPERATION_MODE_IDX,
				HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
			);					
	}

	// note that if couldn't get the Parameter, 
	// it also returns FALSE (but maybe a new Parameter is still needed to be set)
	return bParameterChanged;
}


/*----------------------------------------------------------------------------
* Function name:	Set_RS_Operation_Mode
* Input:			void
* Output:			TRUE  - if setting the parameter has succeed
					FALSE - over wise
* Purpose:			This function will be called only if wants to set
the operation mode as RS.			
*---------------------------------------------------------------------------*/
BOOL Set_RS_Operation_Mode(void)
{
	BOOL bSuccess;
	BOOL bParameterChanged = FALSE;
	WORD wReadParam;

	bSuccess =
		PLCModemDriver_bGetParam
		(
			&wReadParam,
			NLMNG_EI_DB_OPERATION_MODE_IDX,
			HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
		);

	if( (bSuccess) && (wReadParam != NLMNG_EI_DB_OPERATION_MODE_RS) )
	{
		// Set station mode to 'RS'
		// operation mode change requested
		bParameterChanged =
			PLCModemDriver_bSetParam
			(
				(WORD)NLMNG_EI_DB_OPERATION_MODE_RS,
				NLMNG_EI_DB_OPERATION_MODE_IDX,
				HOST_EI_PARAMETER_TABLES_CONFIGURABLE_PARAMS
			);
	}

	// note that if couldn't get the Parameter, 
	// it also returns FALSE (but maybe a new Parameter is still needed to be set)
	return bParameterChanged;
}


/*----------------------------------------------------------------------
* Function name:	IsSerialNumNeeded
* Input:			pbSuccess       - if setting the parameter has succeed,
									  then *pbSuccess gets the TRUE value.
					pbResetRequired - if reset is required, then 
									  *pbResetRequired gets the TRUE value.
* Output:			void
* Purpose:			This function will be called only if wants to set
		            the station serial number.			
*-----------------------------------------------------------------------*/
BOOL IsSerialNumNeeded(void)
{
	int i;
	BYTE pbySNbuffer[PLCModem_DRIVER_SN_LENGTH];
	BOOL bSuccess;
								
	// get device serial number
	bSuccess = PLCModemDriver_bGetSerialNum(pbySNbuffer);
									
	if(bSuccess)
	{
		for(i=0;i<PLCModem_DRIVER_SN_LENGTH;i++)
		{
			// no need to set new Serial Number
			if(pbySNbuffer[i] != 0)
				return FALSE;
		}
		// need to set new Serial Number		
				return TRUE;
	}

	// note that if couldn't get the S/N, 
	// it also returns FALSE (but maybe a new S/N is still needed)
	return FALSE;
}


/*----------------------------------------------------------------------
* Function name:	ClearActivityEvent
* Input:			void
* Output:			void
* Purpose:			This function will be called by activity pin interrupt
					Activity counter should be cleared in this event
*-----------------------------------------------------------------------*/
void ClearActivityEvent(void)
{
	HAL_Timer_ResetActivityCounter();
}

/*----------------------------------------------------------------------
* Function name:	InitModem
* Input:			void
* Output:			void
* Purpose:			Start Modem Init Sequence - exits only when init
*					sequence was completed successfully
*-----------------------------------------------------------------------*/
void InitModem(void)
{
	BOOL bSuccess = FALSE;
	BOOL bResetRequired = TRUE;
	BOOL bParameterChanged = FALSE;
	int  j=1;
	
	while(bResetRequired) // initialization loop
	{
		bResetRequired = FALSE;

		// NOTE: Resetting the modem is necessary to start working.
		//       if reset fails, the system stays on this loop till 
		//		 reset success.
		while(!bSuccess) 
		{
			HAL_UART_UART0_ShowText("Reseting modem: ");
			HAL_UART_UART0_ShowNum(j++);
			HAL_UART_UART0_ShowText(" tries. \r\n");
			bSuccess = PLCModemDriver_bReset_PIM_HW();
		}

//		//////////////////// set predefined parameters (BAND)  ///////////////////

//		// The assumption is that the band is set to factory default.
//		// If not using factory default, then uncomment this block
//		// to set predefined Band.
// 
// 		if(bSuccess)
// 		{
// 			bParameterChanged |= bSet_Predefined_Band();
// 		}
		
		
#if STATION_TYPE == NETWORK_CONCENTRATOR
		
		//////////////////// set NC operation mode ///////////////////
		if(bSuccess)
		{
			bParameterChanged |= Set_NC_Operation_Mode();

			// set NC S/N only if the NC don't have a S/N:

			// if the station doesn't have a serial number		
			if(IsSerialNumNeeded())
			{
				// set new serial number to station
				bSuccess &= PLCModemDriver_bSetSerialNum((PBYTE)sbyNcSNs);
				
				if(bSuccess)
					bParameterChanged |= TRUE;
			}			
		}

// 		//////////////////////// set admission mode ///////////////////////

// 		// this step is optional
// 		// Uncomment this block only if want to set the BS admission mode
// 		// to 'Admission Application Mode', otherwise it will stay on 
// 		// default ('auto').
//  		if(bSuccess)
//  		{
//  			bParameterChanged |= Set_Admission_Mode();
//  		}


#else //Remote meter station

		//////////////////// set RS operation mode ///////////////////
		if(bSuccess)
		{
			bParameterChanged |= Set_RS_Operation_Mode();

			/* set RS S/N only if the RS don't have a S/N:

				 Note that if you connect more than one RS without S/N,
				 then all of these RS will have the same S/N!!!
				 Moreover, if you are set with admission application mode, 
				 you need to verify that the RS S/N are listed in the 
				 "sbyApprovedRsSNs" table.								*/

			// if the station doesn't have a serial number		
			if(IsSerialNumNeeded())
			{
				// set new serial number to station
				bSuccess &= PLCModemDriver_bSetSerialNum((BYTE*)sbyApprovedRsSNs[0]);
				
				if(bSuccess)
					bParameterChanged |= TRUE;
			}			
		}


#endif

		//////////////////////////////////////////////////////////////////////////////

		// if one of the parameters was changed, than save parameters and reset modem
		if (bParameterChanged)
		{
			PLCModemDriver_bSaveParameters();
			bResetRequired = TRUE;
			bSuccess       = FALSE;
		}
		// no need to reset
		else
			bResetRequired = FALSE;

	}	// end while loop



	if(bSuccess)
	{
		HAL_IO_TurnOnGreen();
		HAL_IO_TurnOffRed();
		bSuccess = PLCModemDriver_bGoOnline();
	}
	else
	{
		HAL_IO_TurnOnRed();
		HAL_IO_TurnOffGreen();
	}

	if (bSuccess)
	{
		HAL_UART_UART0_ShowText("Online\r\n");
	}
	else
	{
		HAL_UART_UART0_ShowText("Error: Not Online\r\n");
	}

	// monitor the version number of the AVR firmware
	HAL_UART_UART0_ShowText("The AVR firmware version number is: ");
	HAL_UART_UART0_ShowNum(MAJOR);
	HAL_UART_UART0_ShowText(".");
	HAL_UART_UART0_ShowNum(MINOR);
	HAL_UART_UART0_ShowText(".");
	HAL_UART_UART0_ShowNum(BUILD);
	HAL_UART_UART0_ShowText("\r\n");

}

/*----------------------------------------------------------------------
* Function name:	main
* Input:			void
* Output:			void
* Purpose:			main application function:
  					1. init modules
					2. init modem
					3. setup modem
					4. manage NL management and PLCModem interfaces
					5. for NC application - poll remote meters
*-----------------------------------------------------------------------*/
int main(void)
{
	int i,j;
	WORD wTimeoutTicks;	

	// Init HAL configurations
	HAL_Init_ConfigureHAL();

	// Init Activity Pin Interrupt
	//HAL_ExtInt_SetCBPfn(ACTIVITY_INT_NUM, ClearActivityEvent);

	//HAL_ExtInt_Arm(ACTIVITY_INT_NUM, eHAL_EXT_INT_TYPE_FALLING);

	// In case the micro-controller (ATMEGA64 in this example) power-up wakeup time
	// is shorter than the PLC Modem power-up wakeup time, then delay 
	// is crucial, in order the PLC Modem will be awake when it gets its first 
	// command from application.
	// Notice that the delay is variable, and it depends on which micro-controller 
	// and power supply is been used. 
	for(i=0;i<0xFFFF;i++)      // delay of 336ms
		for(j=0;j<0x0001;j++); // delay of (336ms)

	// Init PLCModem Driver
	PLCModemDriver_Init();
	
	// Init NL management Handler
	NLMngHandler_Init();
	
	// Init UART Handler
	UARTHandler_Init();


	HAL_IO_SetModemBaudRate();			// in case of using IT900 Modem
										// set to low baud rate (38400bps)

// Set pointer to incoming data packet CB function
#if STATION_TYPE == REMOTE_METER
	PLCModemDriver_SetOnIncomingPacketPointerCB(RS_CB_OnIncomingDataPkt);
	HAL_UART_UART0_ShowText("Initializing Remote Station (RS) \r\n");
#else
	PLCModemDriver_SetOnIncomingPacketPointerCB(NC_CB_OnIncomingDataPkt);
	HAL_UART_UART0_ShowText("Initializing Network Concentrator (NC) \r\n");
#endif


	// Init Modem
	InitModem();


	 wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(POLL_TICKS);
	 for( ; ; )
	 {
		// NL management:
		 // 1. Check if there is incoming NL management packet pending
		 // 2. Check if there admission request pending
		 NLMngHandler_ManageNLMng();
		 // Manage Modem:
		 //   1. Check if there is incoming data packet pending
		 //   2. Check if modem reset occurred
		PLCModemDriver_ManageModem();

		if(PLCModemDriver_bIsTimeoutOccured(wTimeoutTicks))
		{
			//TODO: Do Periodic Work Here
#if STATION_TYPE == NETWORK_CONCENTRATOR
			if(NLMngHandler_bIsNetIDAssigned())
			{
				NC_PollNextMeter();
			}
#endif

/*

			// periodic NOP command to the modem - uncomment this block
			// to use this type of activity check (normal reliability)
			if(!PLCModemDriver_bNOP())
			{
				InitModem();
				ClearActivityEvent();
			}
*/

			wTimeoutTicks = PLCModemDriver_wCalculateTimeoutValue(POLL_TICKS);
		}

		// Check if need to reset modem because of Activity
		// timeout (activity pin was not toggled for 1500 mSec)
		// used for high reliability activity check
		//if (HAL_Timer_wGetActivityCounter() > ACTIVITY_TIMEOUT_IN_TICKS)
		//{
		//	InitModem();
		//	ClearActivityEvent();
		//}
	}

	return 0;
}// end main


