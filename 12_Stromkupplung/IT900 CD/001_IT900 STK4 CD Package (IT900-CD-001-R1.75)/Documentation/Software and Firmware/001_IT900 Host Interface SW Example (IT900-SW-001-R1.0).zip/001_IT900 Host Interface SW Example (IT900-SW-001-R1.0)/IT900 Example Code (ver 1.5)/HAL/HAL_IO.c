#include <HAL_IO.h>


/*----------------------------------------------------------------------
* Function name:		HAL_IO_getPort
* Input:				Port number
* Output:				Port value
* Purpose:				Read IO Port value
*-----------------------------------------------------------------------*/
BYTE HAL_IO_getPort(ePort_t ePort)
{
	BYTE port;
	switch(ePort)
	{
	case ePortB:
		port=(BYTE)PINB;
		break;
	case ePortC:
		port=(BYTE)PINC;
		break;
	case ePortD:
		port=(BYTE)PIND;
		break;
	case ePortE:
		port=(BYTE)PINE;
		break;
	case ePortF:
		port=(BYTE)PINF;
		break;
	case ePortG:
		port=(BYTE)PING;
		break;
	case ePortA:
	default:
		port=(BYTE)PINA;
	}//switch
	return port;
}//getPort*/



/*----------------------------------------------------------------------
* Function name:		HAL_IO_togglePin
* Input:				Port number, bit number, IN/OUT, Value
* Output:				none
* Purpose:				Set Pin Direction/Value.
						This function sets pin direction: IN/OUT and
						Value: for OUT - SET/CLEAR, for IN - with/without
						Pullup
*-----------------------------------------------------------------------*/
void HAL_IO_togglePin(ePort_t ePort,BYTE pin,BYTE direction, BYTE pullOrOutput)
{
	BYTE dir;
	BYTE pulOrOut;

	switch (direction)
	{
	case 0:
		dir = ~(1<<pin);
		break;
	default:
		case 1:
		dir = (1<<pin);
		break;
	}

	switch (pullOrOutput)
	{
	case 0:
		pulOrOut = ~(1<<pin);
		break;
	default:
		case 1:
		pulOrOut = (1<<pin);
		break;
	}

	switch(ePort)
	{
	case ePortB:
		if (direction==0) 
			DDRB=(DDRB)&dir;
		else
			DDRB=(DDRB)|dir;
		if (pullOrOutput==0) 
			PORTB=(PORTB)&pulOrOut;
		else
			PORTB=(PORTB)|pulOrOut;
		break;

	case ePortC:
		if (direction==0) 
			DDRC=(DDRC)&dir;
		else
			DDRC=(DDRC)|dir;
		if (pullOrOutput==0) 
			PORTC=(PORTC)&pulOrOut;
		else
			PORTC=(PORTC)|pulOrOut;
		break;
		
	case ePortD:
		if (direction==0) 
			DDRD=(DDRD)&dir;
		else
			DDRD=(DDRD)|dir;
		if (pullOrOutput==0) 
			PORTD=(PORTD)&pulOrOut;
		else
			PORTD=(PORTD)|pulOrOut;
		break;

	case ePortE:
		if (direction==0) 
			DDRE=(DDRE)&dir;
		else
			DDRE=(DDRE)|dir;
		if (pullOrOutput==0) 
			PORTE=(PORTE)&pulOrOut;
		else
			PORTE=(PORTE)|pulOrOut;
		break;

	case ePortF:
		if (direction==0) 
			DDRF=(DDRF)&dir;
		else
			DDRF=(DDRF)|dir;
		if (pullOrOutput==0) 
			PORTF=(PORTF)&pulOrOut;
		else
			PORTF=(PORTF)|pulOrOut;
		break;

	case ePortG:
		if (direction==0) 
			DDRG=(DDRG)&dir;
		else
			DDRG=(DDRG)|dir;
		if (pullOrOutput==0) 
			PORTG=(PORTG)&pulOrOut;
		else
			PORTG=(PORTG)|pulOrOut;
		break;

	case ePortA:
	default:
		if (direction==0) 
			DDRA=(DDRA)&dir;
		else
			DDRA=(DDRA)|dir;
		if (pullOrOutput==0) 
			PORTA=(PORTA)&pulOrOut;
		else
			PORTA=(PORTA)|pulOrOut;
	}//switch
}//togglePin*/


// STK 2 Leds Debug Functions

/*----------------------------------------------------------------------
* Function name:		HAL_IO_TurnOnRed
* Input:				none
* Output:				none
* Purpose:				Turn On Red Led
*-----------------------------------------------------------------------*/
void HAL_IO_TurnOnRed(void)
{
 HAL_IO_togglePin
     (
	     DBG_LED_RED_PORT,
		 DBG_LED_RED_PIN,
		 OUT,
		 SET
     );
}

/*----------------------------------------------------------------------
* Function name:		HAL_IO_TurnOnGreen
* Input:				none
* Output:				none
* Purpose:				Turn On Green Led
*-----------------------------------------------------------------------*/
void HAL_IO_TurnOnGreen(void)
{
  HAL_IO_togglePin
     (
	     DBG_LED_GREEN_PORT,
		 DBG_LED_GREEN_PIN,
		 OUT,
		 SET
     );
}

/*----------------------------------------------------------------------
* Function name:		HAL_IO_TurnOffRed
* Input:				none
* Output:				none
* Purpose:				Turn Off Red Led
*-----------------------------------------------------------------------*/
void HAL_IO_TurnOffRed(void)
{
  HAL_IO_togglePin
     (
	     DBG_LED_RED_PORT,
		 DBG_LED_RED_PIN,
		 OUT,
		 CLEAR
     );
}

/*----------------------------------------------------------------------
* Function name:		HAL_IO_TurnOffGreen
* Input:				none
* Output:				none
* Purpose:				Turn Off Green Led
*-----------------------------------------------------------------------*/
void HAL_IO_TurnOffGreen(void)
{
  HAL_IO_togglePin
     (
	     DBG_LED_GREEN_PORT,
		 DBG_LED_GREEN_PIN,
		 OUT,
		 CLEAR
     );
}

/*----------------------------------------------------------------------
* Function name:		HAL_IO_SetModemBaudRate 
* Input:				none
* Output:				none
* Purpose:				in case of using IT900 Modem:
						set baud rate to 38400 (low baud rate)
*-----------------------------------------------------------------------*/
void HAL_IO_SetModemBaudRate(void)
{
	BOOL bSuccess = FALSE;
	// set pin PD1 of PORTD as output
	DDRD  |=  (1<<DDD1);
	// clear pin PD1 of PORTD
	PORTD &= ~(1<<PD1);
}
