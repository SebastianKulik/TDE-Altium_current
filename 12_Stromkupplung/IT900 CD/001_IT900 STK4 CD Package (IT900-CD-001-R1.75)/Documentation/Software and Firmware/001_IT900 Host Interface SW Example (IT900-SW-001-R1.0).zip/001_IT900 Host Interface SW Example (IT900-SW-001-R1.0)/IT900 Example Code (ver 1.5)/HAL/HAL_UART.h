#include <HAL_Portability.h>
#include <io.h>
#include <stdio.h>
#include <string.h>
#include <avr/interrupt.h>


#ifndef HAL_UART_H
#define HAL_UART_H

#ifdef  HAL_UART_H_MAIN_FILE
#define	HAL_UART_H_EXT
#else
#define	HAL_UART_H_EXT	extern
#endif

// Defines:
/* UART Buffer Defines */

#define UART0_RX_BUFFER_SIZE 64   /* 2,4,8,16,32,64,128 or 256 bytes */
#define UART0_TX_BUFFER_SIZE 64   /* 2,4,8,16,32,64,128 or 256 bytes */

#define UART0_RX_BUFFER_MASK ( UART0_RX_BUFFER_SIZE - 1 )
#define UART0_TX_BUFFER_MASK ( UART0_TX_BUFFER_SIZE - 1 )

#define UART1_RX_BUFFER_SIZE 128  /* 2,4,8,16,32,64,128 or 256 bytes */
#define UART1_TX_BUFFER_SIZE 64   /* 2,4,8,16,32,64,128 or 256 bytes */

#define UART1_RX_BUFFER_MASK ( UART1_RX_BUFFER_SIZE - 1 )
#define UART1_TX_BUFFER_MASK ( UART1_TX_BUFFER_SIZE - 1 )


#if ( UART0_RX_BUFFER_SIZE & UART0_RX_BUFFER_MASK )
	#error RX0 buffer size is not a power of 2
#endif

#if ( UART0_TX_BUFFER_SIZE & UART0_TX_BUFFER_MASK )
	#error TX0 buffer size is not a power of 2
#endif

#if ( UART1_RX_BUFFER_SIZE & UART1_RX_BUFFER_MASK )
	#error RX1 buffer size is not a power of 2
#endif

#if ( UART1_TX_BUFFER_SIZE & UART1_TX_BUFFER_MASK )
	#error TX1 buffer size is not a power of 2
#endif




//#define UART1_DoubleSpeed     //enable this mark for uart1 double speed
//#define UART0_DoubleSpeed     //enable this mark for uart0 double speed


// Define Frame Format:

#define NumOf_StopBit    0  

//  mark 0 for 1 stop bit
//  mark 1 for 2 stop bits

#define NumOf_DataBits   3    //number of data bits in a frame.

//	mark 0 for 5 bits
//	mark 1 for 6 bits				 	
//  mark 2 for 7 bits
//  mark 3 for 8 bits
//  mark 7 for 9 bits

// Define UART baud rate:

// note: when working on PLC Studio mode, baudrate of UART0 and UART1 should be the same
#define UART1_BaudRate  5  // Set the UART1 baudrate to 38,400 bps using a 3.6864MHz crystal 
#define UART0_BaudRate  5  // Set the UART0 baudrate to 38,400 bps using a 3.6864MHz crystal 

/*
 Baud Rate table (fosc = 3.6864 MHz ):

 			       AVR 162: 	  	 	   		 	 	  AVR128:
 
 Baud        U2X = 0          U2X = 1 	 	 	   U2X = 0            U2X = 1 
 Rate     UBRR   Error    UBRR    Error 		 UBRR   Error     UBRR    Error  
 (bps)
  
 2400      95    0.0%     191     0.0%           95      0.0%      191      0.0%
 4800      47    0.0%      95     0.0% 			 47 	 0.0% 	   95 		0.0%
 9600      23    0.0%      47     0.0% 			 23 	 0.0% 	   47 		0.0%
 14.4k     15    0.0%      31     0.0% 			 15 	 0.0% 	   31 		0.0%
 19.2k     11    0.0%      23     0.0% 			 11 	 0.0% 	   23 		0.0%
 28.8k      7    0.0%      15     0.0% 			  7 	 0.0% 	   15 		0.0%
 38.4k      5    0.0%      11     0.0% 			  5 	 0.0% 	   11 		0.0%
 57.6k      3    0.0%       7     0.0% 			  3 	 0.0% 	   7 		0.0%
 76.8k      2    0.0%       5     0.0% 			  2 	 0.0% 	   5 		0.0%
 115.2k     1    0.0%       3     0.0% 			  1 	 0.0% 	   3 		0.0%
 230.4k     0    0.0%       1     0.0% 			  0 	 0.0% 	   1 		0.0%
 250k       0   -7.8%       1    -7.8% 			  0 	 -7.8% 	   1 		-7.8%
 0.5M       �      �        0    -7.8% 			  � 	 � 		   0 		-7.8%
 1M         �      �        �       � 			  � 	 �		    � 		�
 Max       230.4 kbps      460.8 kbps			  230.4 kbps 		460.8 kbps		
 
*/

 
 
// define HAL errors 

#define UART0_RxBuffer_OverFlow  0x01  
#define UART1_RxBuffer_OverFlow  0x02 			

typedef BOOL(*UART_pfCBOnRxByte)(BYTE byData, BYTE byEvent);



/* Prototypes */

//UART0 functions:
HAL_UART_H_EXT void HAL_UART_UART0Init(unsigned int baudRate);// see HAL defenitions.h baudRate table
HAL_UART_H_EXT void HAL_UART_UART0_Transmit(PBYTE data,WORD length);
HAL_UART_H_EXT void HAL_UART_UART0_Transmit_Byte(BYTE byData);
HAL_UART_H_EXT BYTE HAL_UART_UART0_Receive(void);
HAL_UART_H_EXT BYTE HAL_UART_UART0_DataInRxBuf(void);
HAL_UART_H_EXT BYTE HAL_UART_UART0_DataInTxBuf(void);
HAL_UART_H_EXT void HAL_UART_UART0_CB_OnRxLocalByte(BYTE byData);
HAL_UART_H_EXT void HAL_UART_UART0_SetOnRxByteCB(UART_pfCBOnRxByte pfn);
HAL_UART_H_EXT void HAL_UART_UART0_ShowNum(WORD wNum);
HAL_UART_H_EXT void HAL_UART_UART0_ShowText(char * text);
HAL_UART_H_EXT void HAL_UART_UART0_NewLine(void);
HAL_UART_H_EXT void HAL_UART_UART0_ShowNumHex(WORD wNum);

//UART1 functions:
HAL_UART_H_EXT void HAL_UART_UART1Init(unsigned int baudRate);// see HAL defenitions.h baudRate table
HAL_UART_H_EXT void HAL_UART_UART1_Transmit(PBYTE data,WORD length);
HAL_UART_H_EXT void HAL_UART_UART1_Transmit_Byte(BYTE byData);
HAL_UART_H_EXT BYTE HAL_UART_UART1_Receive(void);
HAL_UART_H_EXT BYTE HAL_UART_UART1_DataInRxBuf(void);
HAL_UART_H_EXT BYTE HAL_UART_UART1_DataInTxBuf(void);
HAL_UART_H_EXT void HAL_UART_UART1_CB_OnRxLocalByte(BYTE byData);
HAL_UART_H_EXT void HAL_UART_UART1_SetOnRxByteCB(UART_pfCBOnRxByte pfn);

typedef 
	struct HAL_UART_GLOBAL_T
    {
    
	/* UART0 Variables */
	
	BYTE  UART0_RxBuf[UART0_RX_BUFFER_SIZE]; // buffer for storing the incoming bytes from UART0 interrupt
	BYTE  UART0_TxBuf[UART0_TX_BUFFER_SIZE]; // buffer for storing the bytes that are waiting to be transferd threw UART0 .
	volatile BYTE  UART0_RxHead; // current index of last received byte in UART0_RxBuf
    volatile BYTE  UART0_RxTail; // current index of the last free space in the UART0_RxBuf.
    volatile BYTE  UART0_TxHead; // current index of last received byte in UART0_TxBuf		 		  	   				    
	volatile BYTE  UART0_TxTail;//current index of the last free space in the UART0_TxBuf.
	UART_pfCBOnRxByte UART0_CB_OnRxByte;
		
	/* UART1 Variables */
    BYTE  UART1_RxBuf[UART1_RX_BUFFER_SIZE];// buffer for storing the incoming bytes from UART1 interrupt
	BYTE  UART1_TxBuf[UART1_TX_BUFFER_SIZE];// buffer for storing the bytes that are waiting to be transferd threw UART1.
    volatile BYTE  UART1_RxHead; // current index of last received byte in UART1_RxBuf
	volatile BYTE  UART1_RxTail; // current index of the last free space in the UART1_RxBuf.		   		
	volatile BYTE  UART1_TxHead; // current index of the last free space in the UART0_RxBuf.
	volatile BYTE  UART1_TxTail; // current index of the last free space in the UART0_TxBuf.
	UART_pfCBOnRxByte UART1_CB_OnRxByte;
	
	volatile BYTE  EROR;
	
	} UART_GLOBAL_T;


typedef enum _HAL_UART_EVENT
{
	eHAL_UART_EVENT_UART0_Rx_Event = 0,
	eHAL_UART_EVENT_APPLICATION_UART0_Tx_Event,
	eHAL_UART_EVENT_UART1_Rx_Event,
	eHAL_UART_EVENT_APPLICATION_UART1_Tx_Event
} 
HAL_UART_EVENT;

//Interrupts declerations:

//uart0 Rx complete interrupt
//#pragma interrupt_handler HAL_UART_UART0_RxInterrupt:iv_USART0_RX 

//uart0 Tx complete interrupt-NOT IN USE BY THIS PROGRAM
//#pragma interrupt_handler UART0_Tx_interrupt:iv_USART0_TX 

//UART0 data register empty interrupt
//#pragma interrupt_handler HAL_UART_UART0_DataRegEmptyInterrupt:iv_USART0_DRE

//UART1 Rx complete interrupt-NOT IN USE BY THIS PROGRAM
//#pragma interrupt_handler HAL_UART_UART1_RxInterrupt:iv_USART1_RX 

//UART1 Tx complete interrupt-NOT IN USE BY THIS PROGRAM
//#pragma interrupt_handler UART1_Tx_interrupt:iv_USART0_TX 

//UART1 data register empty interrupt-NOT IN USE BY THIS PROGRAM
//#pragma interrupt_handler HAL_UART_UART1_DataRegEmptyInterrupt:iv_USART1_DRE

//#pragma interrupt_handler EI_PBInterrupt:iv_INT4

// Global Variables:

extern UART_GLOBAL_T Hal;

#endif


